gcc -c pile.c -g
gcc -c tp3.c -g
gcc pile.o tp3.o -o tp3 -g
rm *.o
rm *~
