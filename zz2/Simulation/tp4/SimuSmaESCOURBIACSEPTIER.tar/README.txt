Simulation SMA ZZ2F2
Escourbiac-Septier

Informations pour le compilation:

Le projet nécessite l'installation des library suivantes.

SDL-devel-1.2 et supérieur.
SDL_image-1.2 et supérieur.
FMOD 3.75. (FMOD Ex est non supporté).



