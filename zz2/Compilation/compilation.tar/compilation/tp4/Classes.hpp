#ifndef CLASSES_HPP
#define CLASSES_HPP

class Expr;
class ExprI;
class ExprN;
class ExprBop;
class ExprAff;
class ExprCalc;

#endif
