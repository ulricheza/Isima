
#include ``VisitorExprSquelette.hpp''

void VisitorExprSquelette::VisitExpr_n(Expr_n *inExpr) {

}

void VisitorExprSquelette::VisitExpr_bop(Expr_bop *inExpr) {

}

// fin du fichier VisitorExprSquelette.cpp
