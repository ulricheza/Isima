#ifndef BOP_HPP
#define BOP_HPP
enum Bop {plus, minus, mult, divi};
#define PLUS 0
#define MINUS 1
#define MULT 2
#define DIVI 3
#endif
