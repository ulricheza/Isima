
typedef union  {
   int   entier;
   int   no_ident;
   char *chaine;
} YYSTYPE;
YYSTYPE yylval;
# define CSTE_ENTIERE 257
# define CSTE_CHAINE 258
# define IDENT 259
# define LE 260
# define GE 261
# define NE 262
# define AFFECT 263
# define AND 264
# define ARRAY 265
# define FBEGIN 266
# define CONST 267
# define ELSE 268
# define END 269
# define FUNCTION 270
# define IF 271
# define NIL 272
# define NOT 273
# define OF 274
# define OR 275
# define PROGRAM 276
# define RECORD 277
# define RETURN 278
# define STRING 279
# define THEN 280
# define TYPE 281
# define VAR 282
# define WHILE 283
# define XOR 284
# define INTEGER 285
# define FOR 286
# define TO 287
# define LOOP 288
