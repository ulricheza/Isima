Maxime ESCOURBIAC
Jean-Christophe SEPTIER

README about Groovy Continous Integration Application

- Classes documentes (Javadoc non fourni)
- Utilisation d'une property por le nombre de thread concurrent ( il sera situe dans le dossier ressource dans le dossier release)
- Toutes le sorties de l'application seront loggues (les log seront disponible dans le dossier log dans le dossier release)
- Les intervalles entre les executions des scripts sont en secondes (Pour tester plus facilement)
- Les fichiers build (build.xml et buildhudson.xml) sont pr�sent dans le workspace
- Le choix de deux fichiers build sont voulues car le programme en th�orie ne se termine pas ce qui est pas pratique pour Hudson.
- Donc build.xml servira seulement pour le developpeur et buildhudson.xml pour l'integration ( target run absente).