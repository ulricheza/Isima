int a = 0
int b = 1
int temp;
for(int i = 2 ; i <= 10; ++i)
{
	temp = b
	b = b + a;
	a = temp;
}
return b