int res = 1;
for(i=2;i<=10;++i)
{
   res = res*i
}
return res