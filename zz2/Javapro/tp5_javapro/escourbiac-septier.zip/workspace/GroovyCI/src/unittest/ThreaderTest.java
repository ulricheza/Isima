package unittest;


import groovyci.Threader;
import java.io.IOException;
import junit.framework.Assert;
import junit.framework.TestCase;

public class ThreaderTest extends TestCase {
	public void testThreader()
	{
		System.out.println("**********TestThreader**********");
		int[] intervals = new int[4];
		intervals[0] = 10;
		intervals[1] = 10;
		intervals[2] = 10;
		intervals[3] = 10;
		
		Threader launcher = null;
		try
		{
			launcher = new Threader();
		}
		catch (SecurityException e)
		{
			Assert.fail();
		}
		catch (IOException e)
		{
			Assert.fail();
		}
		
		String[] files1 = new String[4];
		files1[0] = "/Users/maximeescourbiac/Documents/workspace/GroovyCI/ressourcesunittest/HelloWorld.groovy";
		files1[1] = "/Users/maximeescourbiac/Documents/workspace/GroovyCI/ressourcesunittest/bidon.groovy";
		files1[2] = "/Users/maximeescourbiac/Documents/workspace/GroovyCI/ressourcesunittest/OlaMundo.groovy";
		files1[3] = "/Users/maximeescourbiac/Documents/workspace/GroovyCI/ressourcesunittest/bidon.groovy";
		assertEquals(true, launcher.launch(files1, intervals));	
		
	}
}
