package unittest;

import groovyci.Builder;
import junit.framework.Assert;
import junit.framework.TestCase;

public class BuilderTest extends TestCase {

	public void testBuilder()
	{
	    System.out.println("**********TestBuilder**********");
	    try
	    {
	    	Builder build1 = new Builder("./ressourcesunittest/HelloWorld.groovy");
	    	Builder build2 = new Builder("./ressourceunittest/bidon.groovy");
	    	Builder build3 = new Builder("./ressourcesunittest/OlaMundo.groovy");
	    
	    	//Test d'un script juste
	    	build1.run();
	    	assertEquals(null,build1.getReturnValue());
		
	    	//test d'un script inexistant
	    	build2.run();
	    	assertEquals("Erreur fichier script non trouve", build2.getReturnValue());
		
	    	//test d'un script faux (erreur de syntaxe)
	    	build3.run();
	    	assertEquals("Erreur a l'execution du script", build3.getReturnValue());
	    }
	    catch(Exception e)
	    {
	    	System.out.println(e.toString());
	    	Assert.fail();
	    }
	}
}
