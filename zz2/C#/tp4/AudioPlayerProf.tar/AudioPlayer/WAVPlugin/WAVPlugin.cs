﻿using System;
using System.IO;
using AudioPlayer;

namespace WAVPlugin
{
    /// <summary>
    /// Plugin de lecture de données audio au format wav.
    /// </summary>
    [Format("wav")]
    public class WAVPlugin : IAudioPlugin
    {
        #region IAudioPlugin Membres

        public void Decode(byte[] data)
        {
            System.Media.SoundPlayer player = new System.Media.SoundPlayer(new MemoryStream(data, false));

            player.PlaySync();
        }

        #endregion
    }
}
