using System;
using System.Collections.Generic;
using System.Text;
using AudioPlayer;

namespace MP3Plugin
{
    /// <summary>
    /// Plugin de lecture de donn�es audio au format mp3. La gestion du mp3
    /// n�cessite l'utilisation d'APIs externes (DirectX, lame), du coup je
    /// ne me suis pas amus� � l'impl�menter. Le plugin convertit simplement
    /// les donn�es en cha�ne de caract�res et l'affiche.
    /// </summary>
    [Format("mp3")]
    public class MP3Plugin : IAudioPlugin
    {
        #region IAudioPlugin Membres

        public void Decode(byte[] data)
        {
            Console.WriteLine("mp3 > " + 
                System.Text.ASCIIEncoding.ASCII.GetString(data));
        }

        #endregion
    }

    /// <summary>
    /// Plugin suppos� g�rer le mp4 (sert juste � montrer qu'on peut avoir
    /// plusieurs plugins dans un m�me assembly).
    /// </summary>
    [Format("mp4")]
    public class MP4Plugin : IAudioPlugin
    {
        #region IAudioPlugin Membres

        public void Decode(byte[] data)
        {
            Console.WriteLine("mp4 > " + Convert.ToBase64String(data));
        }

        #endregion
    }
}
