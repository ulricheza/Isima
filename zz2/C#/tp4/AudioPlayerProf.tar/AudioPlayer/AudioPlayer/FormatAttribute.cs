using System;

namespace AudioPlayer
{
    /// <summary>
    /// Attribut permettant d'indiquer quel type de format un plugin est
    /// capable de g�rer.
    /// </summary>
    /// <remarks>
    /// On utilise l'attribut <code>AttributeUsage</code> pour indiquer que
    /// l'attribut <code>FormatAttribute</code> ne peut s'appliquer qu'� des
    /// classes ou des structures.
    /// </remarks>
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Struct, 
                    AllowMultiple = true, 
                    Inherited     = true)]
    public class FormatAttribute : Attribute
    {
        public readonly string FormatName;

        public FormatAttribute(string formatName) { FormatName = formatName; }

        public override string ToString()
        {
            return "FormatAttribute : " + FormatName;
        }
    }
}
