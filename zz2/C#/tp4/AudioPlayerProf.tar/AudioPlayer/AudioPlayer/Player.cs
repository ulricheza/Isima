using System;
using System.Xml;
using System.Reflection;

namespace AudioPlayer
{
    /// <summary>
    /// Repr�sente un lecteur audio, qui peut �tre �tendu pour g�rer
    /// plusieurs formats gr�ce � un m�canisme de plugins.
    /// </summary>
    public class Player
    {
        /// <summary>
        /// Fabrique permettant de cr�er des instances � partir d'un format.
        /// </summary>
        Factory playerFactory = new Factory();

        /// <summary>
        /// Joue un fichier audio sous format xml.
        /// </summary>
        /// <param name="fileName">Nom du fichier xml � jouer.</param>
        public void Play(string fileName)
        {
            // Chargement du fichier xml
            XmlDocument doc = new XmlDocument();

            doc.Load(fileName);            

            XmlNode racine     = doc.DocumentElement;
            XmlNode attrFormat = racine.Attributes.GetNamedItem("format");

            if (attrFormat == null)
                throw new IncorrectFileException("Le fichier n'a pas d'attribut format.");

            IAudioPlugin plug;

            try
            {
                // Cr�ation d'une instance capable de g�rer le format du fichier
                plug = (IAudioPlugin)playerFactory.GetInstanceByName(attrFormat.Value);
            }
            catch (ArgumentException ex)
            {
                throw new IncorrectFileException("Le format du fichier n'est pas support�", ex);
            }

            plug.Decode(Convert.FromBase64String(racine.FirstChild.InnerText));
        }

        /// <summary>
        /// Etend le player avec un plugin.
        /// </summary>
        /// <param name="pluginPath">Chemin du plugin.</param>
        public void LoadPlugin(string pluginPath)
        {
            // Chargement de l'assembly contenant le(s) plugin(s)
            Assembly ass = Assembly.LoadFrom(pluginPath);

            foreach (Type type in ass.GetTypes())
            {
                //On r�cup�re uniquement les types qui impl�mentent IAudioPlugin
                //On ne peut pas utiliser IsSubclassOf pour savoir si un
                //type impl�mente une interface. On utilise donc GetInterface
                if (type.GetInterface("AudioPlayer.IAudioPlugin") != null)
                {
                    //On r�cup�re les attributs FormatAttribute
                    object[] attrs =
                        type.GetCustomAttributes(typeof(FormatAttribute), false);

                    if (attrs.Length == 0)
                        throw new IncorrectPluginException(
                            "Le plugin impl�mente IAudioPlugin mais n'a pas d'attribut format.");

                    foreach (object o in attrs)
                    {
                        FormatAttribute fattr = (FormatAttribute)o;

                        // On enregistre le type dans la factory
                        playerFactory.Register(fattr.FormatName, type);
                    }
                }
            }
        }
    }
}
