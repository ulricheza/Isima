using System;
using System.IO;

namespace AudioPlayer
{
    class Program
    {
        /// <summary>
        /// Charge les plugins pr�sents dans le r�pertoire "plugins".
        /// </summary>
        /// <param name="p">Player dans lequel charger les plugins.</param>
        static void LoadPlugins(Player p)
        {
            foreach (string lib in Directory.GetFiles("../../plugins"))
                p.LoadPlugin(lib);              
        }

        /// <summary>
        /// M�thode principale. Cr�e un Player, charge les plugins et joue
        /// quelques fichiers.
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            Player player = new Player();

            LoadPlugins(player);

            try
            {
                player.Play("../../wav_file.xml");
                player.Play("../../false_mp3_file.xml");
            }
            catch (Exception ex)
            {
                Console.Error.WriteLine(ex.Message);
            }

            Console.Read();
        }
    }
}
