using System;
using System.Collections.Generic;

namespace AudioPlayer
{
    /// <summary>
    /// Permet de cr�er une instance de d'un type � partir d'une cha�ne de
    /// caract�res.
    /// </summary>
    class Factory
    {
        /// <summary>
        /// Dictionnaire contenant les paires string/type.
        /// </summary>
        Dictionary<string, Type> nameToTypeMap = new Dictionary<string, Type>();

        /// <summary>
        /// Enregistre un type dans la factory.
        /// </summary>
        /// <param name="name">Cl� repr�sentant le type.</param>
        /// <param name="type">Type.</param>
        public void Register(string name, Type type)
        {
            nameToTypeMap.Add(name, type);
        }

        /// <summary>
        /// Cr�e une instance � partir d'une cl�.
        /// </summary>
        /// <param name="name">
        /// Cl� repr�sentant le type dont on veut obtenir une instance.
        /// </param>
        /// <param name="instance">Instance cr��e</param>
        /// <returns>
        /// Vrai si le type est enregistr� (instance cr��e correctement),
        /// faux sinon.
        /// </returns>
        public bool TryGetInstanceByName(string name, out object instance)
        {
            Type type;

            if (!nameToTypeMap.TryGetValue(name, out type))
            {
                instance = null;
                return false;
            }

            instance = type.GetConstructor(Type.EmptyTypes).Invoke(new Object[0]);
            return true;
        }

        /// <summary>
        /// Cr�e une instance � partir d'une cl�.
        /// </summary>
        /// <param name="name">
        /// Cl� repr�sentant le type dont on veut obtenir une instance.
        /// </param>
        /// <returns>Instance cr��e</returns>
        /// <exception cref="ArgumentException">
        /// Lev�e si la cl� n'est pas enregistr� dans la factory. 
        /// </exception>
        public object GetInstanceByName(string name)
        {
            object res;

            if (!TryGetInstanceByName(name, out res))
                throw new ArgumentException("There is no class registered for " + name + ".");

            return res;
        }
    }
}
