using System;

namespace AudioPlayer
{
    /// <summary>
    /// Exception repr�sentant un plugin incorrect.
    /// </summary>
    public class IncorrectPluginException : Exception
    {
        public IncorrectPluginException() { }
        public IncorrectPluginException(string msg) : base(msg) { }
        public IncorrectPluginException(string msg, Exception inner) : base(msg, inner) { }
    }
}
