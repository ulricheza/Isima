namespace AudioPlayer
{
    /// <summary>
    /// Interface devant �tre impl�ment�e par les plugins de lecture
    /// de donn�es audio.
    /// </summary>
    public interface IAudioPlugin
    {
        /// <summary>
        /// Decode des donn�es musicales.
        /// </summary>
        /// <param name="data">Donn�es � d�coder.</param>
        void Decode(byte[] data);
    }
}
