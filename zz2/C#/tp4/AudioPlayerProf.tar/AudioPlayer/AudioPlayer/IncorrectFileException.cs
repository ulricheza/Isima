using System;

namespace AudioPlayer
{
    /// <summary>
    /// Exception repr�sentant un fichier incorrect.
    /// </summary>
    public class IncorrectFileException : Exception
    {
        public IncorrectFileException() { }
        public IncorrectFileException(string msg) : base(msg) { }
        public IncorrectFileException(string msg, Exception inner) : base(msg, inner) { }
    }
}
