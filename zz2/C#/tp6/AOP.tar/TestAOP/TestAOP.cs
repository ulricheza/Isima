using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

using DesignByContract;
using Memoization;
using Tracing;

[assembly: Trace]

namespace TestAOP
{
    /// <summary>
    ///   Test class for some aspects.
    /// </summary>
    public class TestAOP
    {
        // We don't want Main to be traced
        [Trace(AttributeExclude=true)]
        static void Main(string[] args)
        {
            // Write trace to file
            System.Diagnostics.Trace.AutoFlush = true;
            System.Diagnostics.Trace.Listeners.Add(
                new System.Diagnostics.TextWriterTraceListener("TestAOP.trace"));


            TestAOP test = new TestAOP();

            test.GreetAll(new string[] { "toto", "tata", "toto", "tutu", "toto" });

            // Violate the precondition that name must not be empty
            //Console.WriteLine(test.GetGreetings(null));
            //Console.WriteLine(test.GetGreetings(""));

            Console.ReadKey(true);
        }

        /// <summary>
        ///   Prints a greeting message for all names given by <paramref name="names"/>.
        /// </summary>
        /// <param name="names">
        ///   Names to greet.
        /// </param>
        public void GreetAll(IEnumerable<string> names)
        {
            foreach (string name in names)
            {
                Console.WriteLine(GetGreetings(name));
            }
        }

        /// <summary>
        ///   Returns a greeting message "customized" with a given name.
        /// </summary>
        /// <precondition>
        ///   <paramref name="name"/> must not be empty.
        /// </precondition>
        /// <remarks>
        ///   This method is memoized: when invoked several times with the
        ///   same name, it returns the same greeting message without
        ///   needing recomputation.
        /// </remarks>
        /// <param name="name">
        ///   Name to include in the message.
        /// </param>
        /// <returns>
        ///   A greeting message containing the given name.
        /// </returns>
        [Memoize]
        [NotEmpty("name")]
        public string GetGreetings(string name)
        {
            return String.Format("Hello {0}!", name);
        }
    }
}
