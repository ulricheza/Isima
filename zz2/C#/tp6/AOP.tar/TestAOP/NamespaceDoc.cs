﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TestAOP
{
    /// <summary>
    ///   The TestAOP namespace contains a single class that performs a few
    ///   tests with some aspects.
    /// </summary>
    class NamespaceDoc
    {
    }
}
