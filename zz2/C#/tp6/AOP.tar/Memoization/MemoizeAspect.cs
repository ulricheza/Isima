using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using System.Text;

using PostSharp.Aspects;
using PostSharp.Aspects.Dependencies;
using PostSharp.Extensibility;
using PostSharp.Reflection;

namespace Memoization
{
    /// <summary>
    ///   Aspect performing memoization of the target method.
    /// </summary>
    /// <remarks>
    ///   <para>
    ///     Memoization is an optimization technique that consists in avoiding
    ///     repeating the same computation several times by storing the results
    ///     computed by a function. When the function is called with an argument
    ///     that has already been processed, the result is retrieved and returned
    ///     to the caller. Otherwise, the result is computed and stored for subsequent
    ///     invocations.
    ///   </para>
    ///   <para>
    ///     MemoizeAttribute intercepts invocation of the target method, and checks
    ///     if the function result is already known for the given argument. If so, 
    ///     the target method is not called and the result is returned, otherwise
    ///     the target method is called and the result stored in a hash table, using
    ///     the argument as key.
    ///   </para>
    ///   <para>
    ///     Currently, only single-parameter methods are supported.
    ///   </para>
    /// </remarks>
    /// <example>
    ///   <code>
    ///     using System;
    ///     using Memoization;
    ///     
    ///     public class MemoizeExample
    ///     {
    ///         public static void Main()
    ///         {
    ///             Console.WriteLine(square(2));
    ///             Console.WriteLine(square(3));
    ///             
    ///             Console.WriteLine(square(2));
    ///             Console.WriteLine(square(3));
    ///         }
    ///         
    ///         [Memoize]
    ///         private static int square(int i)
    ///         {
    ///             Console.WriteLine("compute {0} * {0}", i);
    ///             return i * i;
    ///         }
    ///     }
    ///     // This example displays the following output:
    ///     //     compute 2 * 2
    ///     //     4
    ///     //     compute 3 * 3
    ///     //     9
    ///     //     4
    ///     //     9
    ///   </code>
    /// </example>
    [Serializable]
    [AttributeUsage(AttributeTargets.Method, AllowMultiple = false)]
    [ProvideAspectRole(StandardRoles.Caching)]
    [AspectRoleDependency(AspectDependencyAction.Order, AspectDependencyPosition.After, StandardRoles.Tracing)]
    [AspectRoleDependency(AspectDependencyAction.Order, AspectDependencyPosition.After, StandardRoles.Validation)]
    public sealed class MemoizeAttribute : MethodInterceptionAspect
    {
        /// <summary>
        ///   Filters methods with more than one parameter, or ref/out parameter, as well
        ///   as methods with no return.
        /// </summary>
        /// <remarks>
        ///   If the MemoizeAttribute aspect is applied to a method with more than
        ///   one parameter, a ref/out parameter or no return type, a compilation error
        ///   is raised (during weaving).
        /// </remarks>
        /// <param name="method">
        ///   Method to which the aspect has been applied.
        /// </param>
        /// <returns>
        ///   true if the method accepts only one input parameter and returns a
        ///   value, false otherwise.
        /// </returns>
        public override bool CompileTimeValidate(MethodBase method)
        {
            // Must always be a method (not a constructor) ; ensured by AttributeUsage
            System.Diagnostics.Debug.Assert(method is MethodInfo);

            ParameterInfo[] parameters = method.GetParameters();

            if (parameters.Length != 1)
            {
                Message.Write(SeverityType.Error,
                    "MEMOIZED01",
                    "Cannot apply [Memoize] to method {0} because it accepts more than one parameter.",
                    method);

                return false;
            }

            if (parameters[0].ParameterType.IsByRef)
            {
                Message.Write(SeverityType.Error,
                    "MEMOIZED02",
                    "Cannot apply [Memoize] to method {0} because it accepts its parameter by ref.",
                    method);

                return false;
            }

            if ((method as MethodInfo).ReturnType == typeof(void))
            {
                Message.Write(SeverityType.Error,
                    "MEMOIZED03",
                    "Cannot apply [Memoized] to method {0} because it does not return a value.",
                    method);

                return false;
            }

            return true;
        }

        /// <summary>
        ///   Initializes the aspect.
        /// </summary>
        /// <param name="method">
        ///   Method to which the aspect has been applied.
        /// </param>
        // Since all the information we need to initialize the aspect is known
        // at compile-time, we could use CompileTimeInitialize instead; however,
        // for an unknown reason, CompileTimeInitialize is called before
        // CompileTimeValidate, resulting in unclear error messages for the user
        // when the aspect is applied to an invalid method (MakeGenericType throws
        // an exception because the types used are invalid).
        public override void RuntimeInitialize(MethodBase method)
        {
            // We could have use a non-generic Dictionary, but this approach is
            // more typesafe.

            MethodInfo methodInfo = method as MethodInfo;

            Type keyType = methodInfo.ReturnType;
            Type valueType = methodInfo.GetParameters()[0].ParameterType;

            Type cacheType = typeof(Dictionary<,>).MakeGenericType(new Type[] { keyType, valueType });
            cache = (IDictionary)cacheType.GetConstructor(Type.EmptyTypes).Invoke(null);
        }

        /// <summary>
        ///   Intercepts calls to the target method to perform the memoization.
        /// </summary>
        /// <remarks>
        ///   When the target method should be called, this method is invoked
        ///   instead. It performs a lookup in the cache to see if the result
        ///   has already been computed for the given argument, and returns
        ///   it to the caller if that's the case. Otherwise, the target method
        ///   is called and the result saved.
        /// </remarks>
        /// <param name="args">
        ///   Arguments passed to the target method.
        /// </param>
        public override sealed void OnInvoke(MethodInterceptionArgs args)
        {
            object invocationArg = args.Arguments[0];

            if (cache.Contains(invocationArg))
            {
                args.ReturnValue = cache[invocationArg];
            }
            else
            {
                args.Proceed();
                cache[invocationArg] = args.ReturnValue;
            }
        }

        [NonSerialized]
        private IDictionary cache;
    }
}
