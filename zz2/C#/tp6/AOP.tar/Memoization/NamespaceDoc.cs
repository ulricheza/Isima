﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Memoization
{
    /// <summary>
    ///   The Memoization namespace provides an aspect that allows you to
    ///   memoize functions simply by applying the aspect to them.
    /// </summary>
    class NamespaceDoc
    {
    }
}
