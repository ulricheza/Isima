using System;
using System.Collections.Generic;
using System.Diagnostics;

using PostSharp.Aspects;
using PostSharp.Aspects.Dependencies;
using PostSharp.Extensibility;

namespace Tracing
{
    /// <summary>
    ///   Aspect for tracing method calls.
    /// </summary>
    /// <remarks>
    ///   This aspect can be applied to methods or constructors and uses
    ///   <see cref="System.Diagnostics.Trace"/> to log the calls to these
    ///   elements. The trace is indented to show the hierarchy of invocation,
    ///   and each call is tagged with the date and time at which it was
    ///   performed.
    /// </remarks>
    /// <example>
    ///   <code>
    ///     using System;
    ///     using Tracing;
    ///     
    ///     public class TracingExample
    ///     {
    ///         public static void Main()
    ///         {
    ///             System.Diagnostics.Trace.Listeners.Add(
    ///                 new System.Diagnostics.TextWriterTraceListener(Console.Out));
    ///                 
    ///             topLevelMethod();
    ///             lowerLevelMethod();
    ///         }
    ///         
    ///         [Trace]
    ///         private static void topLevelMethod()
    ///         {
    ///             lowerLevelMethod();
    ///             lowerLevelMethod();
    ///         }
    ///         
    ///         [Trace]
    ///         private static void lowerLevelMethod()
    ///         {
    ///         }
    ///     }
    ///     // This example displays the following output (with different dates
    ///     // and times, of course):
    ///     //     16/03/2011 11:39:21: TracingExample.topLevelMethod()
    ///     //         16/03/2011 11:39:21: TracingExample.lowerLevelMethod()
    ///     //         16/03/2011 11:39:21: TracingExample.lowerLevelMethod()
    ///     //     16/03/2011 11:39:21: TracingExample.lowerLevelMethod()
    ///   </code>
    /// </example>
    [Serializable]
    [AttributeUsage(AttributeTargets.Assembly | AttributeTargets.Class |
                    AttributeTargets.Constructor | AttributeTargets.Method |
                    AttributeTargets.Module | AttributeTargets.Struct,
                    AllowMultiple = false)]
    [MulticastAttributeUsage(MulticastTargets.InstanceConstructor | MulticastTargets.Method |
                             MulticastTargets.StaticConstructor,
                             AllowMultiple = false)]
    [ProvideAspectRole(StandardRoles.Tracing)]
    [AspectRoleDependency(AspectDependencyAction.Order, AspectDependencyPosition.After, StandardRoles.Validation)]
    public sealed class TraceAttribute : OnMethodBoundaryAspect
    {
        /// <summary>
        ///   Initializes a part of the log message at compile-time.
        /// </summary>
        /// <param name="method">
        ///   Method to which the aspect has been applied.
        /// </param>
        /// <param name="aspectInfo">
        ///   Unused parameter.
        /// </param>
        public override void CompileTimeInitialize(System.Reflection.MethodBase method, AspectInfo aspectInfo)
        {
            messageFormat = String.Format("{{0}}: {0}({{1}})", method.DeclaringType.FullName + "." + method.Name);
        }

        /// <summary>
        ///   Traces the calls to the target method.
        /// </summary>
        /// <param name="args">
        ///   Arguments passed to the target method.
        /// </param>
        public override void OnEntry(MethodExecutionArgs args)
        {
            List<string> argsStrings = new List<string>();

            foreach (object arg in args.Arguments.ToArray())
            {
                argsStrings.Add(String.Format("{0}", arg));
            }

            Trace.WriteLine(String.Format(messageFormat, DateTime.Now, String.Join(", ", argsStrings.ToArray())));
            Trace.Indent();
        }
        
        /// <summary>
        ///   Invoked on exit of the target method to unindent the trace.
        /// </summary>
        /// <param name="args">
        ///   Arguments passed to the target method.
        /// </param>
        public override void OnExit(MethodExecutionArgs args)
        {
            Trace.Unindent();
        }

        private string messageFormat;
    }
}
