using System;
using System.Collections.Generic;
using System.Text;

using PostSharp.Aspects.Dependencies;

namespace DesignByContract
{
    /// <summary>
    ///   Aspect for checking that a method argument is not empty.
    /// </summary>
    /// <remarks>
    ///   This aspect can be applied to a method to assert that a given argument
    ///   must not be empty (so inevitably not null as well).
    /// </remarks>
    /// <example>
    ///   <code>
    ///     using System;
    ///     using DesignByContract;
    ///     
    ///     public class NotEmptyExample 
    ///     {
    ///         public static void Main()
    ///         {
    ///             string s = "foo";
    ///             char c = getFirstChar(s); // ok, s is not empty: c == f
    ///             
    ///             s = "";
    ///             c = getFirstChar(s); // assertion failed: s is empty
    ///         }
    ///         
    ///         [NotEmpty("s")]
    ///         private static char getFirstChar(string s)
    ///         {
    ///             // s is not empty, we can take the first char confidently
    ///             return s[0];
    ///         }
    ///     }
    ///   </code>
    /// </example>
    [Serializable]
    [ProvideAspectRole(StandardRoles.Validation)]
    public class NotEmptyAttribute : NotNullAttribute
    {
        /// <summary>
        ///   Initializes a new instance of the NotEmptyAttribute aspect with
        ///   the specified parameter name.
        /// </summary>
        /// <param name="parameterName">
        ///   Name of the parameter to be checked by the aspect.
        /// </param>
        public NotEmptyAttribute(string parameterName)
            : base(parameterName)
        {
        }

        /// <summary>
        ///   Determines whether the given object is empty.
        /// </summary>
        /// <param name="arg">
        ///   The object to check for emptiness.
        /// </param>
        /// <returns>
        ///   true if the object is not empty, false otherwise.
        /// </returns>
        protected override bool Check(object arg)
        {
            return base.Check(arg) && arg.ToString().Length != 0;
        }

        /// <summary>
        ///   Returns a string representing the precondition that has been
        ///   violated.
        /// </summary>
        /// <param name="parameterName">
        ///   Name of the parameter that has violated the precondition.
        /// </param>
        /// <returns>
        ///   A string representing the precondition that has been violated.
        /// </returns>
        protected override string Error(string parameterName)
        {
            return string.Format("{0} is empty", parameterName);
        }
    }
}
