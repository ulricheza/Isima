using System;
using System.Collections.Generic;
using System.Text;

using PostSharp.Aspects.Dependencies;

namespace DesignByContract
{
    /// <summary>
    ///   Aspect for checking that a method argument is not null.
    /// </summary>
    /// <remarks>
    ///   This aspect can be applied to a method to assert that a given argument
    ///   must be not null.
    /// </remarks>
    /// <example>
    ///   <code>
    ///     using System;
    ///     using DesignByContract;
    ///     
    ///     public class NotNullExample 
    ///     {
    ///         public static void Main()
    ///         {
    ///             NotNullExample obj = new NotNullExample();
    ///             printType(obj); // ok, obj is not null
    ///             
    ///             obj = null;
    ///             printType(obj); // assertion failed: obj is null
    ///         }
    ///         
    ///         [NotNull("o")]
    ///         private static void printType(object o)
    ///         {
    ///             // o is not null, we can call methods on it
    ///             Console.WriteLine(o.GetType());
    ///         }
    ///     }
    ///   </code>
    /// </example>
    [Serializable]
    [ProvideAspectRole(StandardRoles.Validation)]
    public class NotNullAttribute : ParameterCheckingAttribute
    {
        /// <summary>
        ///   Initializes a new instance of the NotNullAttribute aspect with
        ///   the specified parameter name.
        /// </summary>
        /// <param name="parameterName">
        ///   Name of the parameter to be checked by the aspect.
        /// </param>
        public NotNullAttribute(string parameterName)
            : base(parameterName)
        {
        }

        /// <summary>
        ///   Determines whether the given object reference is null.
        /// </summary>
        /// <param name="arg">
        ///   The object reference to check for "nullness".
        /// </param>
        /// <returns>
        ///   true if the object reference is not null, false otherwise.
        /// </returns>
        protected override bool Check(object arg)
        {
            return arg != null;
        }

        /// <summary>
        ///   Returns a string representing the precondition that has been
        ///   violated.
        /// </summary>
        /// <param name="parameterName">
        ///   Name of the parameter that has violated the precondition.
        /// </param>
        /// <returns>
        ///   A string representing the precondition that has been violated.
        /// </returns>
        protected override string Error(string parameterName)
        {
            return string.Format("{0} is null", parameterName);
        }
    }
}
