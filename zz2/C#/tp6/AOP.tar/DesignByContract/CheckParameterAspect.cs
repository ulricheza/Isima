using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Reflection;
using System.Text;

using PostSharp.Aspects;
using PostSharp.Aspects.Dependencies;
using PostSharp.Extensibility;

namespace DesignByContract
{
    /// <summary>
    ///   Base class for parameter checking aspects.
    /// </summary>
    /// <remarks>
    ///   <para>
    ///     Parameter checking aspects are used to specify precondition on method
    ///     parameters. 
    ///   </para>    
    ///   <para>
    ///     They are applied to a method and parameterized by a parameter
    ///     name. ParameterCheckingAttribute verifies at compile-time that the name
    ///     given is indeed an identifier for one of the method parameters.
    ///     At runtime, at each invocation of the target method, the <see cref="Check"/>
    ///     method is called with the argument corresponding to the given parameter to
    ///     check its validity. If it is not valid, an assertion is raised with an error
    ///     message indicating what precondition was not met, on which method.
    ///   </para>
    ///   <para>
    ///     Aspects deriving from this class must override <see cref="Check"/> and 
    ///     <see cref="Error"/>, which respectively checks the parameter validity
    ///     and returns a string stating why the parameter is not valid.
    ///   </para>
    /// </remarks>
    [Serializable]
    [AttributeUsage(AttributeTargets.Method, Inherited=true)]
    public abstract class ParameterCheckingAttribute : OnMethodBoundaryAspect
    {
        /// <summary>
        ///   Initializes a new instance of the ParameterCheckingAttribute class
        ///   with the specified parameter name.
        /// </summary>
        /// <param name="parameterName">
        ///   Name of the parameter to be checked by the aspect.
        /// </param>
        public ParameterCheckingAttribute(string parameterName)
        {
            ParameterName = parameterName;
        }

        /// <summary>
        ///   Validates the aspect at build time.
        /// </summary>
        /// <remarks>
        ///   This method is invoked during weaving and checks whether 
        ///   <see cref="ParameterName"/> is indeed a parameter of the target
        ///   method. If not, a compilation error is raised.
        /// </remarks>
        /// <param name="method">
        ///   Method to which the aspect has been applied.
        /// </param>
        /// <returns>
        ///   true if the method has a parameter named <see cref="ParameterName"/>,
        ///   false otherwise.
        /// </returns>
        public override bool CompileTimeValidate(MethodBase method)
        {
            bool parameterFound = false;

            foreach (ParameterInfo pi in method.GetParameters())
            {
                if (pi.Name == ParameterName)
                {
                    parameterFound = true;
                    break;
                }
            }

            if (!parameterFound)
            {
                Message.Write(SeverityType.Error, "DBC01",
                    "{0} is not a parameter of {1}.{2}.",
                    ParameterName,
                    method.DeclaringType.FullName,
                    method.Name);
            }

            return parameterFound;
        }

        /// <summary>
        ///   Initializes the aspect at build time.
        /// </summary>
        /// <remarks>
        ///   This method is invoked during weaving and initializes the error
        ///   message that will be used to report precondition violation.
        /// </remarks>
        /// <param name="method">
        ///   Method to which the aspect has been applied.
        /// </param>
        /// <param name="aspectInfo">
        ///   Unused parameter.
        /// </param>
        public override void CompileTimeInitialize(System.Reflection.MethodBase method, AspectInfo aspectInfo)
        {
            foreach (ParameterInfo pi in method.GetParameters())
            {
                if (pi.Name == ParameterName)
                {
                    parameterPosition = pi.Position;
                    break;
                }
            }

            errorMessage = String.Format(
                "Precondition not met for {0}.{1}: {2}.",
                method.DeclaringType.FullName,
                method.Name,
                Error(ParameterName));
        }

        /// <summary>
        ///   When entering the target method, asserts that the precondition is
        ///   not violated.
        /// </summary>
        /// <param name="args">
        ///   Arguments passed to the target method.
        /// </param>
        public override void OnEntry(MethodExecutionArgs args)
        {
            // Instead of using an assertion, we could have used Code Contracts, Microsoft
            // API for design by contract (available in .Net 4.0). However, since both Code
            // Contracts and PostSharp use preprocessing, there could be some conflicts.
            Debug.Assert(Check(args.Arguments[parameterPosition]), errorMessage);
        }

        /// <summary>
        ///   Name of the parameter on which the precondition apply.
        /// </summary>
        public string ParameterName { get; private set; }


        /// <summary>
        ///   Checks if the argument meet the precondition.
        /// </summary>
        /// <param name="arg">
        ///   Value of the argument to be checked.
        /// </param>
        /// <returns>
        ///   true if the argument meet the precondition, false otherwise.
        /// </returns>
        protected abstract bool Check(object arg);

        /// <summary>
        ///   Returns a string representing the precondition that has been
        ///   violated.
        /// </summary>
        /// <param name="parameterName">
        ///   Name of the parameter that has violated the precondition.
        /// </param>
        /// <returns>
        ///   A string representing the precondition that has been violated.
        /// </returns>
        protected abstract string Error(string parameterName);


        private int parameterPosition;
        private string errorMessage;
    }
}
