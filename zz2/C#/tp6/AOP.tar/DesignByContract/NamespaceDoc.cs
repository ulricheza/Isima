﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DesignByContract
{
    /// <summary>
    ///   The DesignByContract namespace provides aspects that allow you to
    ///   define preconditions and postconditions on code elements, as well
    ///   as class invariants, as prescribed by the design by contract paradigm.
    /// </summary>
    /// <remarks>
    ///   Currently, only a very limited number of preconditions are supported.
    /// </remarks>
    class NamespaceDoc
    {
    }
}
