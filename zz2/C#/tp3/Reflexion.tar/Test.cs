using System;
using System.Collections.Generic;
using System.Text;

namespace Reflexion
{
    /// <summary>
    /// Classe dont on va inspecter les m�thodes.
    /// </summary>
    class Test
    {
        // On donne une description � notre m�thode
        [Export("Methode affichant une instance de ClasseBidon sur la console")]
        public void AfficherClasseBidon(ClasseBidon t)
        {
            Console.WriteLine(t);
        }

        // Ici, on sp�cifie �galement le champ auteur
        [Export("M�thode affichant la somme de deux entiers", auteur = "Luc")]
        public void AfficherSomme(int i, int j)
        {
            Console.WriteLine("{0} + {1} = {2}", i, j, i + j);
        }

        [Export("M�thode calculant la somme de deux entiers")]
        public int CalculerSomme(int i, int j)
        {
            return i + j;
        }
    }
}
