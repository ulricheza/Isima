using System;
using System.Collections.Generic;
using System.Text;

namespace Reflexion
{
    /// <summary>
    /// Classe bidon qui servira de param�tre � une m�thode de la classe Test
    /// </summary>
    class ClasseBidon
    {
        public string attr;

        public ClasseBidon()
        {
            attr = "default";
        }

        public ClasseBidon(string s)
        {
            attr = s;
        }

        public override string ToString()
        {
            return "Bidon : " + attr;
        }
    }
}
