using System;
using System.Collections.Generic;
using System.Text;

namespace Reflexion
{
    /// <summary>
    /// Attribut pour d�crire une m�thode.
    /// </summary>
    /// <remarks>
    /// Cet attribut s'applique uniquement aux m�thodes, et ne peut �tre appliqu�
    /// plusieurs fois � la m�me m�thode.
    /// </remarks>
    [AttributeUsage(AttributeTargets.Method, AllowMultiple=false)]
    class ExportAttribute : Attribute
    {
        public string description;
        public string auteur;

        // Comme le constructeur prend une description en param�tre,
        // ce champ est obligatoire. Le nom de l'auteur est optionnel
        // (voir classe Test).
        public ExportAttribute(string description)
        {
            this.description = description;
        }

        public override string ToString()
        {
            StringBuilder builder = new StringBuilder();

            builder.Append(description);

            if (auteur != null)
                builder.AppendFormat(" (by {0})", auteur);

            return builder.ToString();
        }
    }
}
