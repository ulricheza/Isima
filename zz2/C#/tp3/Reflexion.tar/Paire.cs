using System;
using System.Collections.Generic;
using System.Text;

namespace Reflexion
{
    /// <summary>
    /// Simple paire contenant deux valeurs.
    /// </summary>
    /// <typeparam name="T1">Type de la premi�re valeur.</typeparam>
    /// <typeparam name="T2">Type de la deuxi�me valeur.</typeparam>
    class Paire<T1, T2>
    {
        public T1 Premier
        {
            get;
            set;
        }

        public T2 Second
        {
            get;
            set;
        }

        public Paire(T1 premier, T2 second)
        {
            Premier = premier;
            Second  = second;
        }
    }
}
