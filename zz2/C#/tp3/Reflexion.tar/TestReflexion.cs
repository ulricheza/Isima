using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;

namespace Reflexion
{
    /// <summary>
    /// Classe permettant de manipuler un objet grace � la reflexion.
    /// </summary>
    public class TestReflexion
    {
        /// <summary>
        /// Dictionnaire pour stocker les m�thodes de l'instance.
        /// Cl� = nom de la m�thode.
        /// Valeur = liste des diff�rentes surcharges de la m�thode.
        /// </summary>
        Dictionary<string, List<MethodInfo>> dico =
            new Dictionary<string, List<MethodInfo>>();

        /// <summary>
        /// Instance que l'on souhaite manipuler
        /// </summary>
        object instance;

        /// <summary>
        /// Constructeur.
        /// </summary>
        /// <param name="instance">Instance que l'on souhaite manipuler</param>
        public TestReflexion(object instance)
        {
            this.instance = instance;

            chargerMethodes(); // on charge les m�thodes de l'instance dans le dico
        }


        /// <summary>
        /// Charge les m�thodes de l'instance.
        /// </summary>
        void chargerMethodes()
        {
            foreach (MethodInfo mi in instance.GetType().GetMethods())
            {
                List<MethodInfo> methodes;

                if (dico.TryGetValue(mi.Name, out methodes))
                {
                    methodes.Add(mi);
                }
                else
                {
                    methodes = new List<MethodInfo>();
                    methodes.Add(mi);
                    dico.Add(mi.Name, methodes);
                }
            }
        }

        /// <summary>
        /// Affiche la description d'une m�thode � l'�cran.
        /// </summary>
        /// <remarks>
        /// On aurait pu simplement afficher l'objet <paramref name="mi"/>,
        /// mais la m�thode ToString de MethodInfo n'inclue pas le nom des 
        /// param�tres. De plus, on affiche aussi les attributs de la m�thode.
        /// </remarks>
        /// <param name="mi"></param>
        void afficherMethode(MethodInfo mi)
        {
            Console.Write("{0} {1}(", mi.ReturnType.Name, mi.Name);

            // Affichage des param�tres
            bool premierParametre = true;

            foreach (ParameterInfo pi in mi.GetParameters())
            {
                if (premierParametre) premierParametre = false;
                else Console.Write(", ");

                Console.Write(pi);                                       
            }
            Console.WriteLine(")");
            
            // Affichage des attributs
            foreach (Attribute attr in mi.GetCustomAttributes(false))
            {
                Console.WriteLine("    [{0}]", attr);
            }
        }


        /// <summary>
        /// Affiche les m�thodes de l'instance.
        /// </summary>
        public void afficherMethodes()
        {
            foreach (KeyValuePair<string, List<MethodInfo>> paire in dico)
            {
                List<MethodInfo> methodes = paire.Value;

                if (methodes.Count > 1)
                {
                    Console.WriteLine("{0} ({1} surcharges)", 
                                      paire.Key, 
                                      methodes.Count);
                }
                else
                {
                    afficherMethode(methodes[0]);
                }
            }            
        }

        /// <summary>
        /// Construit un objet du type donn� de fa�on interactive avec
        /// l'utilisateur.
        /// </summary>
        /// <remarks>
        /// Cette m�thode ne fonctionne pas avec les pointeurs et les 
        /// param�tres <code>ref</code> et <code>out</code>.
        /// </remarks>
        /// <param name="type">Type de l'objet � construire.</param>
        /// <returns>Un objet du type donn�.</returns>
        public object construire(Type type)
        {
            // Si le type est primitif, on demande � l'utilisateur de saisir
            // une valeur et on la transforme dans le type donn�
            if (type.IsPrimitive || (type == typeof(String)))
            {
                Console.WriteLine("  Entrez un {0} : ", type.Name);

                string s = Console.ReadLine();
                
                // Il faudrait normalement v�rifier que la valeur est bien
                // convertible dans le type donn�

                return Convert.ChangeType(s, type);
            }

            // Sinon on lui demande de choisir parmi diff�rents constructeurs

            ConstructorInfo[] constructeurs = type.GetConstructors();
            int numConstruct;

            do
            {
                numConstruct = 0;

                Console.WriteLine("  Choisissez un constructeur de {0} parmi :",
                                  type.Name);

                foreach (ConstructorInfo ci in constructeurs)
                {
                    Console.WriteLine("    ({0}) {1}", numConstruct++, ci);
                }
            } while (!int.TryParse(Console.ReadLine(), out numConstruct));             

            ConstructorInfo constructeur = constructeurs[numConstruct];

            // On construit les param�tres du constructeur et on l'invoque
            return constructeur.Invoke(
                       construireParams(constructeur.GetParameters()));
        }


        /// <summary>
        /// Construit un tableau de param�tres de fa�on interactive avec 
        /// l'utilisateur.
        /// </summary>
        /// <param name="parameters">
        /// Liste des param�tres � construire.
        /// </param>
        /// <returns>Tableau contenant les valeurs des param�tres.</returns>
        public object[] construireParams(ParameterInfo[] listeParam)
        {
            List<object> parametres = new List<object>(listeParam.Length);

            // On construit chaque param�tre et on l'ajoute � la liste
            foreach (ParameterInfo pi in listeParam)
            {
                Console.WriteLine("  Construction de \"{0}\" :", pi.Name);
                parametres.Add(construire(pi.ParameterType));
            }

            return parametres.ToArray();
        }


        /// <summary>
        /// Permet � l'utilisateur de manipuler l'instance de fa�on
        /// interactive : appel de m�thode, manipulation des retours de
        /// m�thode, affichage.
        /// </summary>
        public void manipulerInstance()
        {
            while(true)
            {
                Console.Clear();
                Console.WriteLine(new string('-', 20));
                Console.WriteLine("  Instance de {0}", instance.GetType().Name);
                Console.WriteLine(new string('-', 20));

                afficherMethodes();

                Console.WriteLine("\n" +
                    "Entrez le nom d'une m�thode pour l'ex�cuter, appuyez " +
                    "sur entr�e pour afficher l'instance, ou tapez \"exit\" " +
                    "pour arr�ter la manipulation :");

                string s = Console.ReadLine();

                // Sortie
                if (s == "exit") return;
                         
                // Affichage de l'instance
                if (s == "")
                {
                    Console.WriteLine(instance);
                    Console.ReadKey(true);
                    continue;
                }

                // Choix d'une m�thode
                List<MethodInfo> methodes;

                try
                {
                    methodes = dico[s];
                }
                catch (KeyNotFoundException ex)
                {
                    Console.Error.WriteLine("Cette m�thode n'existe pas !");
                    Console.ReadKey(true);
                    continue;
                }
                
                MethodInfo mi;

                if (methodes.Count > 1)
                {
                    Console.WriteLine("Choisissez une surcharge parmi :");

                    int i = 0;
                    foreach (MethodInfo meth in methodes)
                    {
                        Console.Write("(" + i++ + ") ");
                        afficherMethode(meth);
                    }

                    int choix = int.Parse(Console.ReadLine());

                    mi = methodes[choix];
                }
                else
                {
                    mi = methodes[0];
                }

                Console.WriteLine("Ex�cution de la m�thode {0} :", mi.Name);                
                
                object res = mi.Invoke(instance, 
                                       construireParams(mi.GetParameters()));
                
                Console.WriteLine("Fin de l'ex�cution de la m�thode {0}", 
                                  mi.Name);
                Console.ReadKey(true);

                if (res != null)
                {                    
                    Console.WriteLine(
                        "Manipulation du r�sultat de la m�thode {0}", mi.Name);
                    Console.ReadKey(true);
                    TestReflexion testReflex = new TestReflexion(res);
                    testReflex.manipulerInstance();
                }            
            }
        }

        /// <summary>
        /// Methode principale. Cr�e une instance de Test et lance la 
        /// manipulation.
        /// </summary>
        /// <param name="args">Param�tres de l'application.</param>
        static void Main(string[] args)
        {
            TestReflexion testReflex = new TestReflexion(new Test());
            testReflex.manipulerInstance();
        }
    }
}
