using System;
using System.Collections.Generic;
using System.Text;

namespace Agents
{
    /// <summary>
    ///   [Singleton]Repr�sente un g�n�rateur de nombres pseudo-al�atoires.
    /// </summary>
    /// <remarks>
    ///   Cette impl�mentation n'est tr�s probablement pas thread-safe.
    /// </remarks>
    public sealed class RNG
    {
        #region Champs

        /// <summary>Instance du singleton.</summary>
        static readonly RNG instance = new RNG();
        /// <summary>G�n�rateur de nombres pseudo-al�atoires</summary>
        private Random rand;

        #endregion

        #region Constructeurs

        /// <summary>Constructeur priv� pour �viter la cr�ation d'instance.</summary>
        private RNG() 
        {
            rand = new Random();
        }

        #endregion

        #region Propri�t�s

        /// <summary>Instance du singleton</summary>
        public static RNG Instance
        {
            get { return instance; }
        }

        #endregion

        #region M�thodes

        /// <summary>
        ///   Retourne un entier tir� al�atoirement entre 0 
        ///   et <paramref name="max"/>.
        /// </summary>
        /// <param name="max">Borne sup�rieure (exclue).</param>
        /// <returns>
        ///   Un entier tir� al�atoirement entre 0 et <paramref name="max"/>
        /// </returns>
        public int NextInt(int max)
        {
            return rand.Next(max);
        }

        #endregion
    }
}
