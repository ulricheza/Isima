using System;
using System.Collections.Generic;
using System.Text;

namespace Agents
{
    class AgentEventArgs : EventArgs
    {
        public readonly int X;
        public readonly int Y;

        public AgentEventArgs(int x, int y)
        {
            X = x;
            Y = y;
        }
    }

    /// <summary>Repr�sente un agent pouvant se d�placer al�atoirement</summary>
    class Agent
    {
        #region Champs
        
        int posX; ///<summary>Position en abcisse de l'agent</summary>
        int posY; ///<summary>Position en ordonn�e de l'agent</summary>

        #endregion

        #region Constructeurs

        /// <summary>Initialise un agent avec ses coordonn�es.</summary>
        /// <param name="x">Abscisse.</param>
        /// <param name="y">Ordonn�e.</param>
        public Agent(int x, int y)
        {
            this.posX = x;
            this.posY = y;
        }

        #endregion

        #region Propri�t�s

        /// <summary>Abscisse.</summary>
        public int X
        {
            get { return posX; }
        }

        /// <summary>Ordonn�e.</summary>
        public int Y
        {
            get { return posY; }
        }

        // Vu la simplicit� des propri�t�s, on aurait pu utiliser des
        // propri�t�s auto-impl�ment�es :
        //
        // public int X { get; private set; } // plus besoin de "posX"
        // public int Y { get; private set; } // plus besoin de "posY"

        #endregion

        #region M�thodes

        /// <summary>D�place l'agent al�atoirement.</summary>
        /// <remarks>
        ///   Le d�placement en x et en y est tir� al�atoirement
        ///   entre -1 et 1.
        /// </remarks>
        public void Move()
        {
            posX += RNG.Instance.NextInt(3) - 1;
            posY += RNG.Instance.NextInt(3) - 1;
            OnMoved(new AgentEventArgs(X, Y) ); // D�clenchement de l'�v�nement "moved"
        }

        #endregion

        #region D�l�gu�s et �v�nements

        /// <summary>
        ///   Repr�sente la m�thode qui traitera le changement d'�tat d'un 
        ///   agent.
        /// </summary>
        /// <param name="args">Arguments d�crivant la nouvelle position de l'agent.</param>
        //public delegate void AgentEventHandler(AgentEventArgs args);
        
        /// <summary>
        /// Se produit apr�s le d�placement de l'agent.
        /// </summary>
        //public event AgentEventHandler Moved;
        public event EventHandler<AgentEventArgs> Moved;

        protected virtual void OnMoved(AgentEventArgs args)
        {
            if (Moved != null) Moved(this, args);
        }

        #endregion
    } 
}
