﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Agents
{
    /// <summary>
    ///   Fenêtre principale de l'application.
    /// </summary>
    public partial class MainWindow : Form
    {
        Timer timer;
        Graphics graph;

        /// <summary>Initialise la fenêtre.</summary>
        /// <remarks>
        ///   Crée un timer et le démarre, et ajoute un handler pour
        ///   l'évènement MouseClick (engendre la création d'un agent).
        /// </remarks>
        public MainWindow()
        {
            InitializeComponent();

            // Création puis lancement du timer
            timer = new Timer();
            timer.Interval = 100;
            timer.Start();

            graph = CreateGraphics();

            // Ajout d'une méthode anonyme à l'évènement MouseClick de la fenêtre
            // Cette méthode crée un agent et enregistre les handlers nécessaires.
            // L'utilisation d'une méthode anonyme n'était pas nécessaire ici.
            MouseClick += delegate(object source, MouseEventArgs args) // Méthode anonyme
            {
                CreateAgent(args.X, args.Y);
            };
        }

        /// <summary>
        /// Crée un agent aux coordonnées passées en paramètre.
        /// </summary>
        /// <param name="x">Abcisse.</param>
        /// <param name="y">Ordonnée.</param>
        public void CreateAgent(int x, int y)
        {
            Agent a = new Agent(x, y);

            // Ajout de la méthode drawAgent à l'évènement Moved de l'agent créé
            a.Moved += drawAgent;

            // Ajout d'une méthode anonyme à l'évènement Tick du timer
            // Cette méthode fait simplement bouger l'agent.
            // La méthode anonyme "capture" l'objet a, ce qui signifie
            // qu'il continuera d'exister tant que le délégué existera
            // (autrement dit tant que le timer existera).
            timer.Tick += delegate { a.Move(); };
        }


        /// <summary>
        /// Dessine un cercle rouge représentant un agent.
        /// </summary>
        /// <param name="a">Agent à dessiner</param>
        private void drawAgent(object a, AgentEventArgs args)
        {
            graph.DrawEllipse(new Pen(Color.Red), args.X, args.Y, 1, 1);
        }
    }
}