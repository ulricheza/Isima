
#include "string.hpp"

#include <cstring>

#include <iostream>

#define nullptr NULL

String::String()
   : taille_( 0 ),
     tab_( nullptr )
{
   std::cout << "Constructeur par defaut." << std::endl;
}

String::String( int inTaille )
   : taille_( inTaille ),
     tab_( new char[ taille_ + 1 ] )
{
   tab_[ 0 ] = '\0';
}

String::String( const char * inTab )
   : taille_( strlen( inTab ) ),
     tab_( new char[ taille_ + 1 ] )
{
   std::cout << "Constructeur a partir d'une chaine." << std::endl;
   strcpy( tab_, inTab );
}

String::String( const String & inString )
   : taille_( inString.taille_ ),
     tab_( new char[ taille_ + 1 ] )
{
   std::cout << "Constructeur de copie." << std::endl;
   strcpy( tab_, inString.tab_ );
}

String::~String()
{
   delete[] tab_;
}

unsigned int String::getTaille() const
{
   return taille_;
}

String & String::operator=( const String & inString )
{
   using std::swap;

   String tmp( inString );

   swap( taille_, tmp.taille_ );
   swap( tab_, tmp.tab_ );

   return *this;
}

char & String::operator[]( int inIndice )
{
   return tab_[ inIndice ];
}

char String::operator[]( int inIndice ) const
{
   return tab_[ inIndice ];
}

void String::toScreen() const
{
   std::cout << tab_ << std::endl;
}

std::ostream & operator<<( std::ostream & inO, const String & inString )
{
   for ( unsigned int i = 0; i < inString.getTaille(); ++i )
   {
      inO << inString[ i ];
   }
   return inO;
}

String operator+( const String & inStrGauche, const String & inStrDroite )
{
   String tmp( inStrGauche.taille_ + inStrDroite.taille_ );

   strcpy( tmp.tab_, inStrGauche.tab_ );
   strcat( tmp.tab_, inStrDroite.tab_ );

   return tmp;
}
