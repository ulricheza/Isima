
#ifndef STRING_HPP_JCAUX
#define STRING_HPP_JCAUX

#include <iostream>

class String
{
   private :
      unsigned int   taille_;
      char *         tab_;

   public :
      String();
      explicit String( int inTaille );
      String( const char * inTab );
      String( const String & inString );
      ~String();

      unsigned int getTaille() const;

      String & operator=( const String & inString );

      char & operator[]( int inIndice );
      char   operator[]( int inIndice ) const;

      void toScreen() const;

   friend String operator+( const String & inStrGauche, const String & inStrDroite );
};

std::ostream & operator<<( std::ostream & inO, const String & inString );
String operator+( const String & inStrGauche, const String & inStrDroite );

#endif
