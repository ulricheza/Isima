
#include "string.hpp"

#include <iostream>

void displayByValue( String inString );
void displayByRef( const String & inString );

int main()
{
   std::cout << "\n\tTest du constructeur par defaut" << std::endl;

   std::cout << "Construction de s1 ... " << std::endl;
   String     s1;
   std::cout << "... fini. " << std::endl;

         // ---------------------------------- //

   std::cout << "\n\tTest du constructeur prenant une chaine" << std::endl;

   std::cout << "Construction de s2 ... " << std::endl;
   String     s2( "Hello World !" );
   std::cout << "... fini. " << std::endl;

         // ---------------------------------- //

   std::cout << "\n\tTest du constructeur de copie" << std::endl;

   std::cout << "Construction de s3 ... " << std::endl;
   String     s3( s2 );
   std::cout << "... fini. " << std::endl;

         // ---------------------------------- //

   std::cout << "\n\tTest des fonctions d'affichages" << std::endl;

   std::cout << "Appel de displayByValue( s3 ) ... " << std::endl;
   displayByValue( s3 );
   std::cout << "... fini. " << std::endl;
   std::cout << "Appel de displayByRef( s3 ) ... " << std::endl;
   displayByRef( s3 );
   std::cout << "... fini. " << std::endl;

         // ---------------------------------- //

   std::cout << "\n\tTest du constructeur prenant une taille" << std::endl;

   std::cout << "Construction de s4 ... " << std::endl;
   String     s4( 10 );
   std::cout << "... fini. " << std::endl;
   std::cout << "Construction de s5 ... " << std::endl;
   String     s5( 20 );
   std::cout << "... fini. " << std::endl;
   std::cout << "Construction de s6 ... " << std::endl;
   String     s6( 15 );
   std::cout << "... fini. " << std::endl;
   std::cout << "s6 = s5 = s4 ... " << std::endl;
   s6 = s5 = s4;
   std::cout << "... fini. " << std::endl;

         // ---------------------------------- //

   std::cout << "\n\tTest du l'affichage et de l'operateur []" << std::endl;

   std::cout << "std::cout << s3 << std::endl; ... " << std::endl;
   std::cout << s3 << std::endl;
   std::cout << "... fini. " << std::endl;

         // ---------------------------------- //

   std::cout << "\n\tTest de l'operateur de concatenation" << std::endl;

   std::cout << "Construction de s7 ... " << std::endl;
   String     s7( "Foo Bar" );
   std::cout << "... fini. " << std::endl;
   std::cout << "s3 + s7 ... " << std::endl;
   std::cout << s3 + s7 << std::endl;
   std::cout << "... fini. " << std::endl;
   std::cout << "\"Toto Tutu\" + s7 ... " << std::endl;
   std::cout << "Toto Tutu" + s7 << std::endl;
   std::cout << "... fini. " << std::endl;


   return 0;
}

void displayByValue( String inString )
{
   inString.toScreen();
}

void displayByRef( const String & inString )
{
   inString.toScreen();
}
