
#include <iostream>

#include "templateStack.hpp"

int main()
{
   TemplateStack< float >   maPileFloat( 5 );

   maPileFloat.push( 4.35 );
   maPileFloat.push( 2.87 );
   maPileFloat.push( 100 );
   maPileFloat.push( 56 );
   maPileFloat.push( 28 );
   maPileFloat.push( 15.3 );
   maPileFloat.push( 6.1 );

   std::cout << "maPileFloat.push( 4.35 )" << std::endl;
   std::cout << "maPileFloat.push( 2.87 )" << std::endl;
   std::cout << "maPileFloat.push( 100 )" << std::endl;
   std::cout << "maPileFloat.push( 56 )" << std::endl;
   std::cout << "maPileFloat.push( 28 )" << std::endl;
   std::cout << "maPileFloat.push( 15.3 )" << std::endl;
   std::cout << "maPileFloat.push( 6.1 )" << std::endl;
   std::cout << "maPileFloat.getNbElements() : " << maPileFloat.getNbElements() << std::endl<< std::endl ;

   std::cout << "maPileFloat.top() : " << maPileFloat.top() << std::endl;
   std::cout << "maPileFloat.getNbElements() : " << maPileFloat.getNbElements() << std::endl<< std::endl ;

   std::cout << "maPileFloat.pop()" << std::endl;
   maPileFloat.pop();
   std::cout << "maPileFloat.getNbElements() : " << maPileFloat.getNbElements() << std::endl << std::endl ;

   std::cout << "maPileFloat.top() : " << maPileFloat.top() << std::endl;
   std::cout << "maPileFloat.getNbElements() : " << maPileFloat.getNbElements() << std::endl << std::endl ;

   return 0;
}
