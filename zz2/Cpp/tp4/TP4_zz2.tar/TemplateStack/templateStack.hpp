
#ifndef TEMPLATEVECTOR_HPP
#define TEMPLATEVECTOR_HPP

template <typename T>
class TemplateStack
{
   private :
      T *          base_;     // Base du tableau de la pile.
      T *          sp_;       // Pointeur sur le dernier element non affecte de la pile.
      unsigned int size_;     // Taille du tableau d'elements.

      void copy( const TemplateStack & inStack );
      void increaseSize();

   public :
      TemplateStack( unsigned int inSize = 10 );
      TemplateStack( const TemplateStack & inStack );
      ~TemplateStack();
      TemplateStack & operator=( const TemplateStack & inStack );

      void push( const T & inT );
      T & top();
      void pop();
      unsigned int getNbElements() const;
};

#include "templateStack.ipp"

#endif
