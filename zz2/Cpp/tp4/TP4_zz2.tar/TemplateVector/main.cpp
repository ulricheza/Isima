/* =============================================================================== */
/* main.cpp                                                                        */
/* ------------------------------------------------------------------------------- */
/* test de la classe TemplateVector                                                   */
/*                                                                                 */
/* Cree le 05/10/2004                                                              */
/* Modifie le 08/10/2004                                                           */
/* Remodifie le 03/11/2010                                                         */
/* =============================================================================== */

#include <iostream>

using std::cout;
using std::cin;
using std::endl;

#include "TemplateVector.hpp"

int main ( int , char ** )
{
   // typedef float MonType; //OK
   // typedef char MonType; // OK
   typedef int MonType; // OK
   // Creation de 2 instances de la classe TemplateVector

   TemplateVector<MonType> v1 ( 5 ) ;
   TemplateVector<MonType> v2 ( 5 ) ;

   // Saisie des valeurs de v1 pour tester l'indexation

   cout << "Saisie de v1: " << endl ;

   for ( unsigned int i = 0 ; i < 5 ; i++ )
   {
      cout << "v1[" << i << "]= " ;
      cin >> v1 [ i ] ;
   }

   cout << "Affichage de v1: " << v1 << endl ;

   // Saisie des valeurs de v2 pour tester l'indexation

   cout << endl << "Saisie de v2: " << endl ;

   for ( unsigned int j = 0 ; j < 5 ; j ++ )
   {
      cout << "v2[" << j << "]= " ;
      cin >> v2 [ j ] ;
   }

   cout << "Affichage de v2: " << v2 << endl ;

   // Creation d'une instance de la classe TemplateVector
   // pour tester l'affectation (operator =) et l'additon (operator +)

   TemplateVector<MonType> v3 ( 5 ) ;
   v3 = v1 + v2 ;
   cout << endl << "Affichage de v3=v1+v2: " << v3 << endl ;

   // Test de l'operator +  //

   v3 += v3 ;
   cout << endl << "Affichage de v3+=v3: " << v3 << endl ;

   // Creation d'une instance de la classe TemplateVector par copie

   TemplateVector<MonType> v4 ( v3 ) ;
   cout << endl << "Affichage de v4 : " << v4 << endl ;

   return 0 ;
}
