/* =============================================================================== */
/* TemplateVector.hpp                                                              */
/* ------------------------------------------------------------------------------- */
/* Classe vecteur template                                                         */
/*                                                                                 */
/* Cree le 25/11/2010                                                              */
/* =============================================================================== */

#ifndef TEMPLATEVECTOR_HPP
#define TEMPLATEVECTOR_HPP

#include <iosfwd>


template <typename T>
class TemplateVector;

template <typename T>
TemplateVector<T> operator + ( const TemplateVector<T> & inV1 , const TemplateVector<T> & inV2 ) ;
template <typename T>
std::ostream & operator << ( std::ostream & inOstream , const TemplateVector<T> & inVector ) ;

template <typename T>
class TemplateVector
{
   private:

      T *          tabT_;    // adresse du tableau d'elements
      unsigned int size_;    // taille du tableau d'elements

   public:

      TemplateVector  ( unsigned int inSize = 10     ) ;
      TemplateVector  ( const TemplateVector & inVector ) ;
      ~TemplateVector (                                 ) { delete [] tabT_; }

      inline unsigned int getSize      (                      ) const { return size_                ; }
      inline T            getElementAt ( unsigned int inIndex ) const { return tabT_[ inIndex ] ; }

      inline void setElementAt ( unsigned int inIndex , T inValue ) { tabT_[ inIndex ]  = inValue ; }

      T              & operator [ ] ( unsigned int inIndex            ) ;         // operateur d'indexation
      T                operator [ ] ( unsigned int inIndex            ) const ;   // operateur d'indexation (lecture seule)
      TemplateVector & operator =   ( const TemplateVector & inVector ) ;         // operateur d'affectation
      void             operator +=  ( const TemplateVector & inVector ) ;         // operateur +=

      // fonctions amies externes a la classes

      friend TemplateVector operator +  <> ( const TemplateVector & inV1 , const TemplateVector & inV2 ) ;
      friend std::ostream & operator << <> ( std::ostream & inOstream , const TemplateVector & inVector ) ;

} ;

void errorMessage ( const char * inMessageToDisplay );   // fonction utilitaire pour ce TP

#include "TemplateVector.ipp"

#endif

/* =============================================================================== */
