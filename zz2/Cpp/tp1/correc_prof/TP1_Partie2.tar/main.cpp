
#include "mere.hpp"
#include "fille.hpp"

#include <iostream>

int main()
{
   std::cout << "Creation d'une instance de Mere avec id par defaut." << std::endl;
   Mere     maMere;
   std::cout << std::endl;

   std::cout << "Creation d'une instance de Mere avec id 42." << std::endl;
   Mere     maMere_id( 42 );
   std::cout << std::endl;

   // La ligne suivante compile uniquement si l'attribut id_ est public
   //std::cout << "maMere_id.id_ : " << maMere_id.id_ << std::endl;

   // La ligne suivante doit toujours compiler car les getters sont publics
   std::cout << "Recuperation de l'id de l'instance ayant pour id 42." << std::endl;
   std::cout << "maMere_id.getId() : " << maMere_id.getId() << std::endl << std::endl;

   std::cout << "Apres 2 instanciation :\n\t"
             << "Mere::GetCmp() : " << Mere::GetCmp() << std::endl << std::endl;

   std::cout << "Creation d'une troisieme instance (de Fille cette fois ci)." << std::endl;
   Mere *   ptMere      = new Fille( 34 );
   std::cout << std::endl;
   std::cout << "Apres 3 instanciation :\n\t"
             << "Mere::GetCmp() : " << Mere::GetCmp() << std::endl << std::endl;

   delete ptMere;
   std::cout << "Apres 3 instanciation ET le delete d'une instance :\n\t"
             << "Mere::GetCmp() : " << Mere::GetCmp() << std::endl << std::endl;

   std::cout << "Creation d'une instance de Fille avec id 69." << std::endl;
   Fille    maFille( 69 );
   std::cout << std::endl;

   std::cout << "Recuperation de l'id de l'instance de Fille ayant pour id 69." << std::endl;
   std::cout << "maFille.getId() : " << maFille.getId() << std::endl;
   maFille.setId( 404 );
   std::cout << std::endl;
   std::cout << "Recuperation de l'id de l'instance de Fille ayant modifier son id pour 404." << std::endl;
   std::cout << "maFille.getId() : " << maFille.getId() << std::endl << std::endl;

   std::cout << "Appel de whoami depuis un instance de Mere." << std::endl;
   std::cout << "maMere.whoami() : ";
   maMere.whoami();
   std::cout << std::endl << std::endl;

   std::cout << "Appel de whoami depuis un instance de Fille." << std::endl;
   std::cout << "maFille.whoami() : ";
   maFille.whoami();
   std::cout << std::endl << std::endl;

   return 0;
}
