
#include "mere.hpp"

#include <iostream>

int Mere::Cmp_    = 0;

Mere::Mere( int inId )
   : id_( inId )
{
   ++Cmp_;

   std::cout << "Identifiant : " << id_ << std::endl;
}

Mere::~Mere()
{
   --Cmp_;
}

int Mere::getId() const
{
   return id_;
}

void Mere::setId( int inId )
{
   id_      = inId;
}

int Mere::GetCmp()
{
   return Cmp_;
}

void Mere::whoami() const
{
   std::cout << "Mere" << std::endl;
}
