
#include "fille.hpp"

#include <iostream>

Fille::Fille( int inId )
   : Mere( inId )
{
}

Fille::~Fille()
{
}

void Fille::whoami() const
{
   std::cout << "Fille" << std::endl;
}
