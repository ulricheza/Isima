
#ifndef FILLE_HPP_JCAUX
#define FILLE_HPP_JCAUX

#include "mere.hpp"

class Fille : public Mere
{
   public :
      Fille( int inId = 0 );
      virtual ~Fille();

      virtual void whoami() const;
};

#endif
