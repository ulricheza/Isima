
#ifndef MERE_HPP_JCAUX
#define MERE_HPP_JCAUX

class Mere
{
   private :
      int         id_;
      static int  Cmp_;

   public :
      Mere( int inId = 0 );
      virtual ~Mere();

      int getId() const;
      void setId( int inId );

      static int GetCmp();

      virtual void whoami() const;
};

#endif
