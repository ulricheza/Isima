
#ifndef B_HPP_JCAUX
#define B_HPP_JCAUX

class A;

class B
{
   private :
      int         j_;

   public :
      B();

      int getJ();

      void exec( int inAjout );
      void send( A * inA );
};

#endif
