
#include "a.hpp"

#include "b.hpp"

A::A()
   : i_( 0 )
{
}

int A::getI()
{
   return i_;
}

void A::exec( int inAjout )
{
   i_ += inAjout;
}

void A::send( B * inB )
{
   inB->exec( 24 );
}
