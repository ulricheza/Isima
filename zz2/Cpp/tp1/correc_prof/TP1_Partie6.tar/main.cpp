
#include <iostream>

#include "a.hpp"
#include "b.hpp"

int main()
{
   A  a;
   B  b;

   std::cout << "Apres la construction de a et b : \n";
   std::cout << "a.getI() : " << a.getI() << "\n";
   std::cout << "b.getJ() : " << b.getJ() << "\n" << std::endl;

   a.exec( 4 );
   b.exec( 1 );
   std::cout << "Apres les appels a exec suivant : \n";
   std::cout << "- a.exec( 4 )\n";
   std::cout << "- b.exec( 1 )\n";
   std::cout << "a.getI() : " << a.getI() << "\n";
   std::cout << "b.getJ() : " << b.getJ() << "\n" << std::endl;

   a.send( &b );
   std::cout << "Apres l'appel a a.send( &b ) : \n";
   std::cout << "a.getI() : " << a.getI() << "\n";
   std::cout << "b.getJ() : " << b.getJ() << "\n" << std::endl;

   return 0;
}
