
#ifndef A_HPP_JCAUX
#define A_HPP_JCAUX

class B;

class A
{
   private :
      int         i_;

   public :
      A();

      int getI();

      void exec( int inAjout );
      void send( B * inB );
};

#endif
