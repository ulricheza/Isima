
#include "b.hpp"

#include "a.hpp"

B::B()
   : j_( 0 )
{
}

int B::getJ()
{
   return j_;
}

void B::exec( int inAjout )
{
   j_ += inAjout;
}

void B::send( A * inA )
{
   inA->exec( 42 );
}
