
#include <iostream>

//Partie 1

void swap( int * inEntier1, int * inEntier2 )
{
   int   tmp      = *inEntier1;
   *inEntier1     = *inEntier2;
   *inEntier2     = tmp;
}

void swap( int & inEntier1, int & inEntier2 )
{
   int   tmp      = inEntier1;
   inEntier1      = inEntier2;
   inEntier2      = tmp;
}

void swap( float & inEntier1, float & inEntier2 )
{
   float   tmp    = inEntier1;
   inEntier1      = inEntier2;
   inEntier2      = tmp;
}

int main( int, char *[] )
{
   // Point 1-3
   std::cout << "Hello world!" << std::endl;

   // Point 4-5
   int      entier1     = 8;
   int      entier2     = -1;
   std::cout << "Entier 1 : " << entier1 << "\nEntier 2 : " << entier2 << "\n\n";
   swap( &entier1, &entier2 );
   std::cout << "Entier 1 : " << entier1 << "\nEntier 2 : " << entier2 << "\n\n";
   swap( entier1, entier2 );
   std::cout << "Entier 1 : " << entier1 << "\nEntier 2 : " << entier2 << "\n\n";

   // Point 6
   float    reel1     = 8.5;
   float    reel2     = -1.2;
   std::cout << "Reel 1 : " << reel1 << "\nReel 2 : " << reel2 << "\n\n";
   swap( reel1, reel2 );
   std::cout << "Reel 1 : " << reel1 << "\nReel 2 : " << reel2 << "\n\n";

   return 0;
}
