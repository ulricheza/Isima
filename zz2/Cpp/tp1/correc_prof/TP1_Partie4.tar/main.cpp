#include<iostream>

class A
{
   public:
      A() { std::cout << "A ";}
      ~A() { std::cout << "~A ";}
};

class B : virtual public A
{
   public:
      B() { std::cout << "B "; }
      ~B() { std::cout << "~B ";}
};

class C : virtual public A {
   public:
      C() { std::cout << "C ";}
      ~C() { std::cout << "~C ";}
};

class D : virtual public B, virtual public C
{
   public:
      D() { std::cout << "D ";}
      ~D() { std::cout << "~D ";}
};

int main(int, char**)
{
   D d;

   std::cout << std::endl << "C'est fini !" << std::endl;

   return 0 ;
}
