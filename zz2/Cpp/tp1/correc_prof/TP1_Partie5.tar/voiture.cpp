
#include "voiture.hpp"

const char * Voiture::Parcours::parcours[] = { "urbaine", "extra urbaine" };

const char * Voiture::Parcours::toString( Enum e )
{
   return parcours[ e ];
}

unsigned int Voiture::NbInstance_ = 0;

Voiture::Voiture(
                  const std::string & inMarque,
                  const std::string & inCouleur,
                  unsigned int        inPuissance,
                  unsigned int        inRegimeMax,
                  unsigned int        inConso[ Voiture::Parcours::NB_PARCOURS ],
                  unsigned int        inCapaReservoir,
                  unsigned int        inEmissionCO2
                )
   : marque_( inMarque ),
     couleur_( inCouleur ),
     puissance_( inPuissance ),
     regimeMax_( inRegimeMax ),
     capaReservoir_( inCapaReservoir ),
     niveauReservoir_( 0 ),
     emissionCO2_( inEmissionCO2 )
{
   for ( int i = 0; i < Parcours::NB_PARCOURS; ++i )
   {
      conso_[ i ]    = inConso[ i ];
   }

   ++NbInstance_;
}

Voiture::~Voiture()
{
   --NbInstance_;
}

int Voiture::GetNbInstance()
{
   return NbInstance_;
}

const std::string & Voiture::getMarque() const
{
   return marque_;
}

const std::string & Voiture::getCouleur() const
{
   return couleur_;
}

unsigned int Voiture::getPuissance() const
{
   return puissance_;
}

unsigned int Voiture::getRegimeMax() const
{
   return regimeMax_;
}

unsigned int Voiture::getConso( Voiture::Parcours::Enum inParcours ) const
{
   return conso_[ inParcours ];
}

unsigned int Voiture::getCapaReservoir() const
{
   return capaReservoir_;
}

unsigned int Voiture::getNiveauReservoir() const
{
   return niveauReservoir_;
}

unsigned int Voiture::getEmissionCO2() const
{
   return emissionCO2_;
}

void Voiture::faireLePlein()
{
   niveauReservoir_ = capaReservoir_;
}

void Voiture::rouler( unsigned int inNbKiloMetre, Parcours::Enum inParcours )
{
   unsigned int   besoinCarburant = static_cast<unsigned int>( conso_[ inParcours ] / 100.0 * inNbKiloMetre );

   if ( niveauReservoir_ < besoinCarburant )
   {
      std::cerr << "Il n'y a pas suffisament de carburant pour faire le trajet." << std::endl;
   }
   else
   {
      niveauReservoir_ -= conso_[ inParcours ] / 100.0 * inNbKiloMetre;
   }
}

void Voiture::afficher()
{
   std::cout << "\tMarque : "                               << marque_        << std::endl;
   std::cout << "\tCouleur : "                              << couleur_       << std::endl;
   std::cout << "\tPuissance (din) : "                      << puissance_     << std::endl;
   std::cout << "\tRegime moteur maximum  (trs/min) : "     << regimeMax_     << std::endl;
   for ( int i = 0; i < Parcours::NB_PARCOURS; ++i )
   {
      std::cout << "\tConsomation " << Parcours::toString( Parcours::Enum( i ) ) << " (L/100km) : "        << conso_[ i ] << std::endl;
   }
   std::cout << "\tCapacit� du reservoir (L) : "            << capaReservoir_ << std::endl;
   std::cout << "\tEmission de CO2 (g/km : "                << emissionCO2_   << std::endl;
}

std::ostream & operator<< ( std::ostream & inO, const Voiture & inVoiture )
{
   inO << "\tMarque : "                               << inVoiture.getMarque()         << std::endl;
   inO << "\tCouleur : "                              << inVoiture.getCouleur()        << std::endl;
   inO << "\tPuissance (din) : "                      << inVoiture.getPuissance()      << std::endl;
   inO << "\tRegime moteur maximum  (trs/min) : "     << inVoiture.getRegimeMax()      << std::endl;
   for ( int i = 0; i < Voiture::Parcours::NB_PARCOURS; ++i )
   {
      std::cout << "\tConsomation " << Voiture::Parcours::toString( Voiture::Parcours::Enum( i ) ) << " (L/100km) : "        << inVoiture.getConso( Voiture::Parcours::Enum( i ) ) << std::endl;
   }
   inO << "\tCapacit� du reservoir (L) : "            << inVoiture.getCapaReservoir()  << std::endl;
   inO << "\tEmission de CO2 (g/km : "                << inVoiture.getEmissionCO2()    << std::endl;

   return inO;
}
