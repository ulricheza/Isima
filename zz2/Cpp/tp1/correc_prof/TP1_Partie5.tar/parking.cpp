
#include "parking.hpp"

ParkingStatique::ParkingStatique()
   : cmpVoiture_( 0 )
{
}

ParkingStatique::~ParkingStatique()
{
}

unsigned int ParkingStatique::GetTailleMax()
{
   return TailleMax_;
}

unsigned int ParkingStatique::getCmpVoiture() const
{
   return cmpVoiture_;
}

Voiture * ParkingStatique::getVoiture( unsigned int i ) const
{
   if ( i < cmpVoiture_ )
   {
      return tabVoiture_[ i ];
   }
   else
   {
      return NULL;
   }
}

void ParkingStatique::ajoutVoiture( Voiture * inVoiture )
{
   if ( cmpVoiture_ < TailleMax_ )
   {
      tabVoiture_[ cmpVoiture_++ ]  = inVoiture;
   }
}

void ParkingStatique::afficher()
{
   std::cout << "Le parking comprend " << cmpVoiture_ << " sur " << TailleMax_ << " voiture(s)." << std::endl;
   for ( unsigned int i = 0; i < cmpVoiture_; ++i )
   {
      std::cout << i + 1 << "eme voiture :" << std::endl;
      tabVoiture_[ i ]->afficher();
      std::cout << std::endl;
   }
}

std::ostream & operator<< ( std::ostream & inO, const ParkingStatique & inParking )
{
   inO << "Le parking comprend " << inParking.getCmpVoiture() << " sur " << ParkingStatique::GetTailleMax() << " voiture(s)." << std::endl;
   for ( unsigned int i = 0; i < inParking.getCmpVoiture(); ++i )
   {
      inO << i + 1 << "eme voiture :" << std::endl;
      inO << *( inParking.getVoiture( i ) ) << std::endl;
   }

   return inO;
}





ParkingDynamique::ParkingDynamique( unsigned int inTailleTab )
   : tailleTab_( inTailleTab ),
     cmpVoiture_( 0 ),
     tabVoiture_( new Voiture *[ tailleTab_ ] )
{
}

ParkingDynamique::~ParkingDynamique()
{
   delete[] tabVoiture_;
}

unsigned int ParkingDynamique::getTailleTab() const
{
   return tailleTab_;
}

unsigned int ParkingDynamique::getCmpVoiture() const
{
   return cmpVoiture_;
}

Voiture * ParkingDynamique::getVoiture( unsigned int i ) const
{
   if ( i < cmpVoiture_ )
   {
      return tabVoiture_[ i ];
   }
   else
   {
      return NULL;
   }
}

void ParkingDynamique::ajoutVoiture( Voiture * inVoiture )
{
   if ( cmpVoiture_ < tailleTab_ )
   {
      tabVoiture_[ cmpVoiture_++ ]  = inVoiture;
   }
}

void ParkingDynamique::afficher()
{
   std::cout << "Le parking comprend " << cmpVoiture_ << " sur " << tailleTab_ << " voiture(s)." << std::endl;
   for ( unsigned int i = 0; i < cmpVoiture_; ++i )
   {
      std::cout << i + 1 << "eme voiture :" << std::endl;
      tabVoiture_[ i ]->afficher();
      std::cout << std::endl;
   }
}

std::ostream & operator<< ( std::ostream & inO, const ParkingDynamique & inParking )
{
   inO << "Le parking comprend " << inParking.getCmpVoiture() << " sur " << inParking.getTailleTab() << " voiture(s)." << std::endl;
   for ( unsigned int i = 0; i < inParking.getCmpVoiture(); ++i )
   {
      inO << i + 1 << "eme voiture :" << std::endl;
      inO << *( inParking.getVoiture( i ) ) << std::endl;
   }

   return inO;
}
