
#include <iostream>

#include "voiture.hpp"
#include "parking.hpp"

int main()
{
   unsigned int   consoVoiture1[ Voiture::Parcours::NB_PARCOURS ] = { 13, 10 };
   unsigned int   consoVoiture2[ Voiture::Parcours::NB_PARCOURS ] = { 20, 16 };
   unsigned int   consoVoiture3[ Voiture::Parcours::NB_PARCOURS ] = { 11, 8 };
   Voiture  voiture1( "Renault", "Rouge", 110, 4800, consoVoiture1, 50, 120 );
   Voiture  voiture2( "BMW",     "Verte", 200, 5500, consoVoiture2, 70, 220 );
   Voiture  voiture3( "Fiat",    "Bleu",  80,  4000, consoVoiture3, 40, 98 );

   std::cout << "// ------------------------------------------- //\n";
   std::cout << "//                                             //\n";
   std::cout << "//          Exercices 1), 2) et 3)             //\n";
   std::cout << "//                                             //\n";
   std::cout << "// ------------------------------------------- //\n\n" << std::endl;


   std::cout << "   ==>        Affichage des voitures\n\n";
   voiture1.afficher();
   std::cout << voiture1 << "\n";
   voiture2.afficher();
   std::cout << voiture2 << "\n";
   voiture3.afficher();
   std::cout << voiture3 << "\n";

   std::cout << Voiture::GetNbInstance() << " voiture(s) a (ont) ete cree.\n";
   std::cout << "\n\n" << std::endl;


   std::cout << "   ==>        Utilisation des methodes faireLePlein et rouler\n\n";
   std::cout << "voiture1.faireLePlein()\n";
   voiture1.faireLePlein();
   std::cout << "voiture2.faireLePlein()\n";
   voiture2.faireLePlein();
   std::cout << "voiture3.faireLePlein()\n";
   voiture3.faireLePlein();

   std::cout << "voiture1.getNiveauReservoir() : " << voiture1.getNiveauReservoir() << std::endl;
   std::cout << "voiture1.rouler( 45, Voiture::Parcours::urbain )\n";
   voiture1.rouler( 45, Voiture::Parcours::urbain );
   std::cout << "voiture1.getNiveauReservoir() : " << voiture1.getNiveauReservoir() << std::endl;
   std::cout << "voiture1.rouler( 230, Voiture::Parcours::extra_urbain )\n";
   voiture1.rouler( 230, Voiture::Parcours::extra_urbain );
   std::cout << "voiture1.getNiveauReservoir() : " << voiture1.getNiveauReservoir() << std::endl;
   std::cout << "voiture1.rouler( 800, Voiture::Parcours::extra_urbain )\n";
   voiture1.rouler( 800, Voiture::Parcours::extra_urbain );
   std::cout << "\n\n" << std::endl;


   std::cout << "// ------------------------------------------- //\n";
   std::cout << "//                                             //\n";
   std::cout << "//               Exercice 4)                   //\n";
   std::cout << "//                                             //\n";
   std::cout << "// ------------------------------------------- //\n\n" << std::endl;


   ParkingStatique   parking1;
   ParkingDynamique  parking2( 15 );
   ParkingDynamique  parking3( 600 );

   parking1.ajoutVoiture( &voiture1 );
   parking1.ajoutVoiture( &voiture3 );

   parking2.ajoutVoiture( &voiture1 );
   parking2.ajoutVoiture( &voiture2 );
   parking2.ajoutVoiture( &voiture3 );

   parking3.ajoutVoiture( &voiture2 );

   std::cout << "   ==>        Affichage des parkings via la methode afficher\n\n";
   parking1.afficher();
   parking2.afficher();
   parking3.afficher();
   std::cout << "\n\n" << std::endl;


   std::cout << "   ==>        Affichage des parkings via l'operateur <<\n\n";
   // Utilise avec cout, la surcharge de l'operateur de flux << pour les
   // parking realise exactement la meme sortie ecran.
   std::cout << parking1 << std::endl;
   std::cout << parking2 << std::endl;
   std::cout << parking3 << std::endl;

    return 0;
}
