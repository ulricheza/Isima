
#ifndef PARKING_HPP_JCAUX
#define PARKING_HPP_JCAUX

#include <iostream>

#include "voiture.hpp"

class ParkingStatique
{
   private :
      static const unsigned int  TailleMax_   = 100;
      unsigned int               cmpVoiture_;
      Voiture *                  tabVoiture_[ TailleMax_ ];

   public :
      ParkingStatique();
      ~ParkingStatique();

      static unsigned int GetTailleMax();
      unsigned int getCmpVoiture() const;
      Voiture * getVoiture( unsigned int i ) const;

      void ajoutVoiture( Voiture * inVoiture );

      void afficher();
};

std::ostream & operator<< ( std::ostream & inO, const ParkingStatique & inParking );


class ParkingDynamique
{
   private :
      unsigned int      tailleTab_;
      unsigned int      cmpVoiture_;
      Voiture **        tabVoiture_;

   public :
      ParkingDynamique( unsigned int inTailleTab = 100 );
      ~ParkingDynamique();

      unsigned int getTailleTab() const;
      unsigned int getCmpVoiture() const;
      Voiture * getVoiture( unsigned int i ) const;

      void ajoutVoiture( Voiture * inVoiture );

      void afficher();
};

std::ostream & operator<< ( std::ostream & inO, const ParkingDynamique & inParking );

#endif
