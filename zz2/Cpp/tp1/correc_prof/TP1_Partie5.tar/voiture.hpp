
#ifndef VOITURE_HPP_JCAUX
#define VOITURE_HPP_JCAUX

#include <iostream>

class Voiture
{
   public :
      struct Parcours
      {
         enum Enum {
                     urbain,       // 0
                     extra_urbain, // 1
                     NB_PARCOURS   // 2
                   };

         static const char * toString( Enum e );

         private:
            static const char * parcours[];
      };

   private :
      static unsigned int  NbInstance_;

      std::string    marque_;
      std::string    couleur_;
      unsigned int   puissance_;
      unsigned int   regimeMax_;
      unsigned int   conso_[ Parcours::NB_PARCOURS ];
      unsigned int   capaReservoir_;
      unsigned int   niveauReservoir_;
      unsigned int   emissionCO2_;

   public :
      Voiture(
               const std::string & inMarque,
               const std::string & inCouleur,
               unsigned int        inPuissance,
               unsigned int        inRegimeMax,
               unsigned int        inConso[ Parcours::NB_PARCOURS ],
               unsigned int        inCapaReservoir,
               unsigned int        inEmissionCO2
             );
      ~Voiture();

      static int GetNbInstance();

      const std::string &  getMarque() const;
      const std::string &  getCouleur() const;
      unsigned int         getPuissance() const;
      unsigned int         getRegimeMax() const;
      unsigned int         getConso( Parcours::Enum inParcours ) const;
      unsigned int         getCapaReservoir() const;
      unsigned int         getNiveauReservoir() const;
      unsigned int         getEmissionCO2() const;

      void faireLePlein();
      void rouler( unsigned int inNbKiloMetre, Parcours::Enum inParcours );

      void afficher();
};

std::ostream & operator<< ( std::ostream & inO, const Voiture & inVoiture );

#endif
