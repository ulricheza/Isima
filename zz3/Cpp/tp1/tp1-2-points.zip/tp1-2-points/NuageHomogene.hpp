#ifndef NUAGEHOMOGENE_H_INCLUDED
#define NUAGEHOMOGENE_H_INCLUDED

#include <iterator>
#include <vector>

namespace isima { namespace espace {


/**
 * Repr�sente un nuage de points homog�ne. Les points contenus sont tous du
 * m�me type TPoint.
 */
template<typename TPoint>
class NuageHomogene
{
  public:

    /** Ajoute un point au nuage. */
    void add(const TPoint & point);


    /** It�rateur de nuage. */
    /* Remarque : le mot-cl� typename sert � indiquer au compilateur que
    ce qui vient apr�s est un type. En effet, le compilateur ne peut pas
    �tre sur que "std::vector<TPoint>::iterator" est bien un type car
    "std::vector" peut �tre sp�cialis� pour un TPoint particulier et d�finir
    dans ce cas-l� un membre "iterator" qui ne soit pas un type (ce pourrait
    �tre un attribut par exemple). */
    typedef typename std::vector<TPoint>::iterator iterator;
    /** It�rateur constant de nuage. */
    typedef typename std::vector<TPoint>::const_iterator const_iterator;


    /** Retourne un it�rateur sur le d�but du nuage. */
    iterator begin();
    /** Retourne un it�rateur constant sur le d�but du nuage. */
    const_iterator begin() const;

    /** Retourne un it�rateur sur la fin du nuage. */
    iterator end();
    /** Retourne un it�rateur constant sur la fin du nuage. */
    const_iterator end() const;


    /** Retourne la taille du nuage. */
    std::size_t size() const;


  private:

    std::vector<TPoint> points_; /**< Points contenus dans le nuage. */
};


/** 
 * Calcule le barycentre d'un nuage de points de type TPoint.
 * @return Le barycentre du nuage sous forme de TPoint.
 */
template <typename TPoint>
TPoint barycentre(const NuageHomogene<TPoint> & nuage);


/**
 * Calcule le barycentre des points contenus entre first et last.
 * @return Le barycentre des points, du m�me type que les points manipul�s.
 */
/* Remarque : cette fonction est beaucoup plus g�n�rique que la pr�c�dente car
elle permet de calculer le barycentre de n'importe quel ensemble de points sur
lequel on peut it�rer. Cela inclut notre classe Nuage, mais �galement les
conteneurs de la biblioth�que standard, les tableaux, les flux, etc. */
template<typename InputIterator>
typename std::iterator_traits<InputIterator>::value_type barycentre(InputIterator first, InputIterator last);


}} // namespace isima::espace


// Inclusion de l'implementation des methodes
#include "NuageHomogene.tpp"


#endif // NUAGEHOMOGENE_H_INCLUDED
