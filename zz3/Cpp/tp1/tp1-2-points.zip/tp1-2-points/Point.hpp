#ifndef POINT_H_INCLUDED
#define POINT_H_INCLUDED

#include <iostream>

namespace isima { namespace espace {


class Cartesien; // D�claration anticip�e

/* Remarque:
Pour le calcul du barycentre, on aura besoin de pouvoir convertir n'importe quel
point en cart�sien. Par cons�quent, la class Point aura besoin de la d�claration
de Cartesien. Comme le type Cartesien n'est utilis� que dans un prototype de
m�thode, seule la d�claration est n�cessaire, pas la d�finition (le contenu
de Cartesien n'a pas besoin d'�tre connu). Une d�claration anticip�e est donc
appropri�e (on dit au compilateur que la classe Cartesien existe, mais sans lui
dire ce qu'il y a dedans ; cela permet de limiter les d�pendances entre fichiers
-> une modification de Cartesien.hpp n'impactera aucunement Point.hpp). */


/** Classe de base pour la repr�sentation de points dans l'espace 2D. */
class Point
{
  public:

    /** Convertit le point en Cartesien. */
    /* Remarque : cette m�thode est virtuelle pure. Cela implique d'une part que
    toutes les sous-classes concr�tes de Point devront forc�ment red�finir cette
    m�thode, et d'autre part que Point est une classe abstraite, c'est-�-dire
    une classe qu'on ne peut pas instancier (on ne pourra jamais cr�er d'objet
    Point, il faudra que ce soit un Cartesien ou un Polaire (ou n'importe quel
    autre type concret d�rivant de Point)). */
    virtual Cartesien enCartesien() const = 0;

    /** Affiche le point sur le flux pass� en param�tre. */
    virtual std::ostream & afficher(std::ostream &) const = 0;
    /** Lit le point sur le flux pass� en param�tre. */
    virtual std::istream & lire(std::istream &) = 0;
};

/** Ins�re l'objet Point "point" sur le flux de sortie "sortie". */
std::ostream & operator<<(std::ostream & sortie, const Point & point);

/**
 * Extrait un Point depuis le flux d'entr�e "entree" et stocke le r�sultat
 * dans "point". 
 */
std::istream & operator>>(std::istream & entree, Point & point);

}} // namespace isima::espace


#endif // POINT_H_INCLUDED
