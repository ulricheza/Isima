#include "Point.hpp"

#include <iostream>

namespace isima { namespace espace {


std::ostream & operator<<(std::ostream & sortie, const Point & point)
{
    // utilisation du polymorphisme pour appeler la m�thode "afficher" 
    // de Point ou de Cartesien, selon le type r�el de "point".
    return point.afficher(sortie);
}

std::istream & operator>>(std::istream & entree, Point & point)
{
    return point.lire(entree);
}



/* Remarque sur les conversions :
Selon le type de conversion d�sir�e, plusieurs m�thodes sont possibles pour
convertir d'un type Source vers un type Destination.

Conversion implicite de Source vers Destination :
  - op�rateur de conversion :
  class Source
  {
      operator Destination() const;
  };
  
  - constructeur de conversion :
  class Destination
  {
      Destination(const Source & source);
  };
  

Conversion explicite de Source vers Destination :
  - m�thode de conversion :
  class Source
  {
      Destination toDestination() const;
  };

  - constructeur de conversion explicite :
  class Destination
  {
      explicit Destination(const Source & source);
  };
  
Cas particuliers : si on veut convertir vers un type primitif, on ne peut pas
utiliser de constructeur (les types primitifs ne sont pas des classes, ils
n'ont pas de constructeurs). C'est �galement le cas lorsque la classe de
Destination ne peut pas �tre modifi�e (par exemple parce qu'elle provient d'une
biblioth�que). Dans ces cas-l�, vous �tes oblig� de passer par l'op�rateur de
conversion ou une m�thode, dans la classe Source. */


}} // namespace isima::espace
