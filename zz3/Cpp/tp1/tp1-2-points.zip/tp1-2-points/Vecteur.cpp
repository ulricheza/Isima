#include "Vecteur.hpp"

#include <algorithm>

namespace isima {


Vecteur::Vecteur(unsigned int capacite)
  : donnees_(new int[capacite]),
    taille_(0),
    capacite_(capacite)
{}

Vecteur::Vecteur(const Vecteur & autre)
  : donnees_(new int[autre.capacite()]),
    taille_(autre.taille()),
    capacite_(autre.capacite())
{
    // Copie des elements de autre dans *this
    std::copy(autre.donnees_, autre.donnees_ + taille_, donnees_);
}


Vecteur & Vecteur::operator=(Vecteur rhs)
{
    /* Echange du vecteur courant avec le parametre rhs, qui est une copie de
    l'argument fourni. Ainsi, la memoire occupee par l'objet courant sera
    liberee a la fin de la fonction, quand rhs sera detruit. */

    rhs.swap(*this);
    return *this;
}


Vecteur::~Vecteur()
{
    delete[] donnees_;
}


void Vecteur::swap(Vecteur & autre) throw()
{
    /* La methode/fonction swap consiste a echanger deux objets
    membre-a-membre. On swap donc chacun des attributs. */

    std::swap(donnees_, autre.donnees_);
    std::swap(taille_, autre.taille_);
    std::swap(capacite_, autre.capacite_);
}


void Vecteur::reserver(unsigned int capacite)
{
    if (capacite_ < capacite)
    {
        unsigned int nouvelleCapacite = std::max(static_cast<unsigned int>(capacite_ * 1.5), capacite);
        
        Vecteur nouveauVecteur(nouvelleCapacite);
        
        std::copy(donnees_, donnees_ + taille_, nouveauVecteur.donnees_);
        nouveauVecteur.taille_ = taille_;
        nouveauVecteur.swap(*this);
    }
}


void Vecteur::ajouterDerriere(int i)
{
    reserver(taille_ + 1);
    donnees_[taille_] = i;
    ++taille_;
}


const int & Vecteur::operator[] (unsigned int indice) const
{
    return donnees_[indice];
}


int & Vecteur::operator[] (unsigned int indice)
{
    return donnees_[indice];
}


unsigned int Vecteur::taille() const
{
    return taille_;
}


unsigned int Vecteur::capacite() const
{
    return capacite_;
}


Vecteur::Iterateur Vecteur::debut()
{
    return Iterateur(donnees_);
}


Vecteur::Iterateur Vecteur::fin()
{
    return Iterateur(donnees_ + taille_);
}



// Fonctions libres

void swap(Vecteur & lhs, Vecteur & rhs) throw()
{
    lhs.swap(rhs);
}



// Iterator

Vecteur::Iterateur::Iterateur()
  : courant_(NULL)
{}

Vecteur::Iterateur::Iterateur(int * pi)
  : courant_(pi)
{}


Vecteur::Iterateur & Vecteur::Iterateur::operator++()
{
    ++courant_;
    return *this;
}

Vecteur::Iterateur Vecteur::Iterateur::operator++(int)
{
    Iterateur tmp(*this);
    ++(*this); // Appel a l'operateur d'incrementation prefix.
    return tmp;
}


int & Vecteur::Iterateur::operator*() const
{
    return *courant_;
}


bool operator==(const Vecteur::Iterateur & lhs, const Vecteur::Iterateur & rhs)
{
    return lhs.courant_ == rhs.courant_;
}

bool operator!=(const Vecteur::Iterateur & lhs, const Vecteur::Iterateur & rhs)
{
    return !(lhs == rhs);
}


} // namespace isima

