#include "NuageHeterogene.hpp"

#include "Cartesien.hpp"

namespace isima { namespace espace {


void NuageHeterogene::ajouterPoint(Point * point)
{ 
    points_.push_back(point);
}


NuageHeterogene::iterator NuageHeterogene::begin()
{ 
    return points_.begin(); 
}

NuageHeterogene::const_iterator NuageHeterogene::begin() const 
{ 
    return points_.begin(); 
}


NuageHeterogene::iterator NuageHeterogene::end()
{ 
    return points_.end(); 
}

NuageHeterogene::const_iterator NuageHeterogene::end() const 
{ 
    return points_.end(); 
}


std::size_t NuageHeterogene::size() const 
{ 
    return points_.size(); 
}


Cartesien barycentre(const NuageHeterogene & nuage)
{
    float sommeX  = 0.f;
    float sommeY = 0.f;

    for (NuageHeterogene::const_iterator itPointCourant = nuage.begin() ;
         itPointCourant != nuage.end() ; 
         ++itPointCourant)
    {
        const Cartesien & cartesienCourant = (*itPointCourant)->enCartesien();

        sommeX += cartesienCourant.getX();
        sommeY += cartesienCourant.getY();
    }

    return Cartesien(sommeX / nuage.size(), sommeY / nuage.size());
}

Cartesien Barycentre::operator()(const NuageHeterogene & nuage)
{
    return barycentre(nuage);
}

}} // namespace isima::espace