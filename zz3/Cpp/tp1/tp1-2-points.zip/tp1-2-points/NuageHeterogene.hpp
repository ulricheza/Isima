#ifndef NUAGEHETEROGENE_H_INCLUDED
#define NUAGE_H_INCLUDED

#include <vector>

namespace isima { namespace espace {

    
class Cartesien;
class Point;


/** 
 * Repr�sente un nuage de points h�t�rog�nes. Les points contenus peuvent �tre
 * de types vari�s, par exemple des Cartesiens et des Polaires. Le nuage ne
 * prend pas possession des points.
 */
/* Remarque : nous sommes oblig�s de stocker des pointeurs de Point pour �viter
le slicing, c'est-�-dire la troncature des objets pour ne garder que la partie
"Point". Comme nous stockons des pointeurs, il faut se poser la question "Qui
est en charge de d�truire les points ?". Nous faisons le choix ici de laisser
cette responsabilit� � l'utilisateur de la classe. Il faudra donc qu'il alloue
ses points soit de fa�on automatique, soit de fa�on dynamique en pensant � les
supprimer (ou en les stockant dans un conteneur se chargant de les supprimer
pour lui). */
class NuageHeterogene
{
  public:

    /** Ajoute un point au nuage. */
    void ajouterPoint(Point * point);


    /* Remarque : pour que notre nuage puisse �tre manipul� de fa�on similaire
    aux conteneurs de la biblioth�que standard, nous voulons proposer des
    it�rateurs aux utilisateurs de notre classe afin qu'il puisse parcourir
    le nuage de points. Pour cela, il nous faut un type repr�sentant un
    it�rateur sur le nuage, ainsi que des m�thodes pour obtenir un it�rateur
    sur le d�but et sur la fin du nuage. Comme std::vector<T> propose lui-m�me
    des it�rateurs et des m�thodes de ce genre, on peut simplement r�utiliser
    les siens. */

    /** It�rateur de nuage. */
    typedef std::vector<Point *>::iterator iterator;
    /** It�rateur constant de nuage. */
    /* Remarque : un it�rateur constant n'est pas un it�rateur qui ne peut pas
    �tre modifi�, mais un it�rateur qui ne permet pas de modifier les objets de
    la s�quence. */
    typedef std::vector<Point *>::const_iterator const_iterator;

    /** Retourne un it�rateur sur le d�but du nuage. */
    iterator begin();
    /** Retourne un it�rateur constant sur le d�but du nuage. */
    const_iterator begin() const;

    /** Retourne un it�rateur sur la fin du nuage. */
    iterator end();
    /** Retourne un it�rateur constant sur la fin du nuage. */
    const_iterator end() const;

    /** Retourne la taille du nuage, c-�-d le nombre de points contenus. */
    std::size_t size() const;


  private :

    std::vector<Point *> points_; /**< Points contenus dans le nuage. */
};


/** 
 * Calcule le barycentre d'un nuage de points.
 * @param Le nuage dont le barycentre doit �tre calcul�.
 * @return Le barycentre du nuage pass� en param�tre, en coordonn�es 
 *   cart�siennes.
 */
Cartesien barycentre(const NuageHeterogene & nuage);

/** Foncteur permettant de calculer le barycentre d'un nuage de points. */
/* Remarque : un foncteur est un objet qui peut �tre invoqu� comme une
fonction. L'avantage d'un foncteur par rapport � une fonction, c'est qu'il
peut garder un �tat entre chaque appel, gr�ce � des attributs. */
struct Barycentre
{
    Cartesien operator()(const NuageHeterogene & nuage);
};

}} // namespace isima::espace

#endif // NUAGEHETEROGENE_H_INCLUDED