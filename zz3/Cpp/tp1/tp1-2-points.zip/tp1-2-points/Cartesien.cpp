#include "Cartesien.hpp"

#include <cmath>

#include "Polaire.hpp"

/* Remarque : dans le fichier d'ent�te, la d�claration anticip�e de Polaire
suffisait. Dans le fichier d'impl�mentation, on a besoin d'acc�der � ses
m�thodes, et donc de conna�tre sa d�finition. Par cons�quent, il faut inclure
"Polaire.hpp". */

namespace isima { namespace espace {


Cartesien::Cartesien()
  : x_(0), y_(0)
{}

Cartesien::Cartesien(float x, float y)
  : x_(x), y_(y)
{}

// Constructeur de conversion depuis Polaire.
Cartesien::Cartesien(const Polaire & polaire)
{
    x_ = static_cast<float>(polaire.getRayon() * cos(polaire.getAngle()));
    y_ = static_cast<float>(polaire.getRayon() * sin(polaire.getAngle()));
}


float Cartesien::getX() const 
{ 
    return x_; 
}

float Cartesien::getY() const 
{ 
    return y_; 
}


Cartesien Cartesien::enCartesien() const
{
    return *this;
}


// Ecriture
std::ostream & Cartesien::afficher(std::ostream & sortie) const
{
    return sortie << "(x,y) = (" << x_ << "," << y_ << ")";
}


// Lecture
/** 
 * @TODO: Corriger cette impl�mentation qui r�cup�re les coordonn�es en
 * ignorant les autres caract�res.
 */
std::istream & Cartesien::lire(std::istream & entree)
{
    char c;
    return entree >> c >> x_ >> c >> y_ >> c;
}


}} // namespace isima::espace
