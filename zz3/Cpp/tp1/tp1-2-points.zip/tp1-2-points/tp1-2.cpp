#include <iostream>

#include "Cartesien.hpp"
#include "Polaire.hpp"

#include "pi.hpp"

#include "NuageHeterogene.hpp"
#include "NuageHomogene.hpp"

#include "Vecteur.hpp"

#include <algorithm>


using namespace isima::espace;


void testPoints()
{
    Cartesien cartesienParDefaut;
    std::cout << "Cartesien construit par defaut : " << cartesienParDefaut << '\n';
    Cartesien cartesien(42, 12);
    std::cout << "Cartesien initialise : " << cartesien << '\n';

    Polaire polaireParDefaut;
    std::cout << "Polaire construit par defaut : " << polaireParDefaut << '\n';
    Polaire polaire(68, 3.14);
    std::cout << "Polaire initialise : " << polaire << '\n';

    Point * point = &cartesien;
    std::cout << "Cartesien manipule de facon polymorphique : " << *point << '\n';
    point = &polaire;
    std::cout << "Polaire manipule de facon polymorphique : " << *point << '\n';
}


void testConversionPoints()
{
    Cartesien cartesien(42, 12);
    Polaire cartesienEnPolaire(cartesien);
    std::cout << "Cartesien : " << cartesien << '\n' <<
                 "Cartesien en polaire : " << cartesienEnPolaire << '\n' <<
                 "Cartesien en polaire en cartesien : " << cartesienEnPolaire.enCartesien() << '\n';

    Polaire polaire(68, 3.14);
    Cartesien polaireEnCartesien(polaire);
    std::cout << "Polaire : " << polaire << '\n' <<
                 "Polaire en cartesien : " << polaireEnCartesien << '\n' <<
                 "Polaire en cartesien en polaire : " << Polaire(polaireEnCartesien) << '\n';
}


void testNuageHeterogene()
{
    NuageHeterogene nuage;

    Cartesien c1(1,1);
    Cartesien c2(2,2);
    Cartesien c3(3,3);

    Polaire p1(1, isima::math::Pi);
    Polaire p2(2, isima::math::Pi / 2);
    Polaire p3(3, isima::math::Pi / 4);

    nuage.ajouterPoint(&c1);
    nuage.ajouterPoint(&p1);
    nuage.ajouterPoint(&c2);
    nuage.ajouterPoint(&p2);
    nuage.ajouterPoint(&c3);
    nuage.ajouterPoint(&p3);
    
    std::cout << "Contenu du nuage :" << '\n';

    for (NuageHeterogene::iterator itPointCourant = nuage.begin() ;
         itPointCourant != nuage.end() ;
         ++itPointCourant)
    {
        std::cout << "  " << **itPointCourant << '\n';
    }

    std::cout << "Barycentre du nuage (fonction) : " << barycentre(nuage) << '\n';
    Barycentre foncteurBarycentre;
    std::cout << "Barycentre du nuage (foncteur) : " << foncteurBarycentre(nuage) << '\n';
}

void testNuageHomogene()
{
    NuageHomogene<Cartesien> nuageCartesien;
    NuageHomogene<Polaire> nuagePolaire;

    const int nbPoints = 3;

    for (int i = 0 ; i < nbPoints ; ++i)
    {
        float tmp = static_cast<float>(i);

        nuageCartesien.add(Cartesien(tmp, -tmp));
        nuagePolaire.add(Polaire(tmp, isima::math::Pi / tmp));
    }

    std::cout << "Contenu du nuage cartesien:" << "\n  ";

    std::copy(nuageCartesien.begin(), nuageCartesien.end(), std::ostream_iterator<Cartesien>(std::cout, "\n  "));

    std::cout << "Barycentre du nuage cartesien : " << barycentre(nuageCartesien) << '\n';


    std::cout << "Contenu du nuage polaire:" << '\n';

    std::copy(nuagePolaire.begin(), nuagePolaire.end(), std::ostream_iterator<Polaire>(std::cout, "\n  "));

    std::cout << "Barycentre du nuage polaire : " << barycentre(nuagePolaire) << '\n';
}

void testVecteur()
{
    using isima::Vecteur;

    const int capaciteInitiale = 10;
    Vecteur vecteur(capaciteInitiale);

    std::cout << "Apres initialisation avec capacite initiale\nCapacite >= " << capaciteInitiale << " ? " << vecteur.capacite() << '\n';
    std::cout << "Taille == 0 ? " << vecteur.taille() << '\n';


    const int reservationInferieure = capaciteInitiale - 2;
    vecteur.reserver(reservationInferieure);

    std::cout << "Apres reservation inferieure\nCapacite identique ? " << vecteur.capacite() << '\n';
    std::cout << "Taille == 0 ? " << vecteur.taille() << '\n';


    const int reservationSuperieure = capaciteInitiale + 2;

    vecteur.reserver(reservationSuperieure);

    std::cout << "Apres reservation superieure\nCapacite >= " << reservationSuperieure << " ? " << vecteur.capacite() << '\n';
    std::cout << "Taille == 0 ? " << vecteur.taille() << '\n';


    const int nbElements = 4;

    for (int i = 0 ; i < nbElements ; ++i)
    {
        vecteur.ajouterDerriere(i);
    }

    std::cout << "\nApres ajout\nTaille == " << nbElements << " ? " << vecteur.taille() << '\n';

    std::cout << "Contenu du vecteur : \n  ";
    for (Vecteur::Iterateur it = vecteur.debut() ; it != vecteur.fin() ; ++it)
    {
        std::cout << *it << ' ';
    }


    Vecteur copie(vecteur);

    std::cout << "\n\nContenu de la copie du vecteur : \n  ";
    for (Vecteur::Iterateur it = copie.debut() ; it != copie.fin() ; ++it)
    {
        std::cout << *it << ' ';
    }


    copie = Vecteur(); // affectation avec un vecteur vide

    std::cout << "\n\nApres affectation avec un vecteur vide\nTaille == 0 ? " << copie.taille() << '\n';
}



int main()
{
    std::cout << "Test de creation et d'affichage des points" << "\n\n";

    testPoints();

    std::cout << "-----------------------------" << '\n',
    std::cout << "Test de conversion des points" << "\n\n";

    testConversionPoints();

    std::cout << "-----------------------------" << '\n',
    std::cout << "Test du nuage heterogene" << "\n\n";

    testNuageHeterogene();

    std::cout << "-----------------------------" << '\n',
    std::cout << "Test du nuage homogene" << "\n\n";

    testNuageHomogene();

    std::cout << "-----------------------------" << '\n',
    std::cout << "Test du vecteur" << "\n\n";

    testVecteur();
}
