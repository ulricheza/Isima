#ifndef VECTEUR_H_INCLUDED
#define VECTEUR_H_INCLUDED

namespace isima {


/** Classe repr�sentant un vecteur d'entiers. */
class Vecteur
{
  public:

    /** 
     * Constructeur.
     * @param capacite La capacit� initiale du vecteur, 1 par defaut.
     */
    explicit Vecteur(unsigned int capacite = 1);

    /** 
     * Constructeur de copie.
     */
    Vecteur(const Vecteur &);


    /** 
     * Operateur d'affectation.
     * @param rhs Le vecteur � affecter � l'objet courant.
     */
    Vecteur & operator=(Vecteur rhs);


    /** Destructeur. Lib�re la m�moire allou�e pour stocker les entiers. */
    ~Vecteur();


    /** 
     * Swap l'objet actuel avec le vecteur passe en parametre.
     * (cf "non-throwing swap idiom")
     * @param autre Une reference vers le vecteur avec lequel swapper.
     */
    void swap(Vecteur & autre) throw();


    /** 
     * Si besoin est, augmente la capacite du vecteur pour qu'il puisse
     * contenir "capacite" elements.
     * A chaque nouvelle allocation de memoire, la capacite est multipliee
     * par 1.5, a part si cela ne permet pas d'atteindre la capacite demandee.
     * A ce moment la, la capacite est directement augmentee jusqu'a "capacite".
     * @param capacite La capacite minimum requise par l'appelant.
     */
    void reserver(unsigned int capacite);


    /** 
     * Ajoute un entier a la fin du vecteur.
     * @param i L'entier a ajouter.
     */
    void ajouterDerriere(int i);


    /** 
     * Operateur d'indexation constant.
     * @param index L'indice de l'element.
     * @return Une reference constante vers l'element d'indice "indice".
     */
    const int & operator[] (unsigned int indice) const;

    /** 
     * Operateur d'indexation non constant.
     * @param index L'indice de l'element.
     * @return Une reference non constante vers l'element d'indice "indice".
     */
    int & operator[] (unsigned int indice);


    /** 
     * Retourne le nombre d'elements contenus dans le vecteur.
     * @return La taille du vecteur.
     */
    unsigned int taille() const;

    /** 
     * Retourne la capacite actuelle du vecteur.
     * @return La capacite du vecteur.
     */
    unsigned int capacite() const;


    /** 
     * Iterateur non constant sur un vecteur. Un iterateur non constant
     * ne peut iterer que sur un vecteur non constant. Lorsqu'il est
     * derefence, il renvoie une reference non constante sur l'element courant.
     */
    class Iterateur;


    /** 
     * Retourne un iterateur non constant sur le premier element du vecteur.
     */
    Iterateur debut();

    /**
     * Retourne un iterateur non constant sur la fin du vecteur (l'iterateur
     * pointe apres le dernier element).
     */
    Iterateur fin();


  private:

    int * donnees_; /**< Tableau contenant les entiers. */
    unsigned int taille_; /**< Nombre d'elements dans le vecteur. */
    unsigned int capacite_; /**< Capacite du vecteur. */
};


/** Swap deux vecteurs. */
void swap(Vecteur & lhs, Vecteur & rhs) throw();



class Vecteur::Iterateur
{
  public:

    /** Constructeur par defaut. */
    Iterateur();


    /** 
     * Constructeur.
     * @param pi Un pointeur vers l'element reference par l'iterateur.
     */
    explicit Iterateur(int * pi);


    /**
     * Avance l'iterateur et le retourne.
     * @return L'iterateur actuel, pointant sur l'element suivant.
     */
    Iterateur & operator++();

    /** 
     * Retourne l'itateur et l'avance.
     * @return Un iterateur pointant sur l'element pointe precedemment.
     */
    Iterateur operator++(int);


    /**
     * Operateur de dereferencement.
     * @return Une reference non constante sur l'element pointe.
     */
    int & operator*() const;


  private:

    int * courant_; /**< Pointeur sur l'element reference par l'iterateur. */


    // L'operateur de comparaison a acces aux membres prives d'Iterator.
    friend bool operator==(const Iterateur &, const Iterateur &);
};


bool operator==(const Vecteur::Iterateur & lhs, const Vecteur::Iterateur & rhs);
bool operator!=(const Vecteur::Iterateur & lhs, const Vecteur::Iterateur & rhs);


} // namespace isima


#endif // VECTEUR_H_INCLUDED
