#include "Polaire.hpp"

#include <cmath>

#include "pi.hpp"
#include "Cartesien.hpp"

namespace isima { namespace espace {


Polaire::Polaire()
  : rayon_(0), angle_(0)
{}

Polaire::Polaire(float rayon, double angle)
  : rayon_(rayon), angle_(angle)
{}


// Calcule l'angle entre le point (x,y) et l'axe polaire.
/* Remarque : cette fonction ne sert qu'� clarifier le code du constructeur de
Polaire. Pour qu'elle ne soit pas visible par les utilisateurs de Polaire, elle
n'est pas d�clar�e dans le header et est donc invisible hors de ce fichier
d'impl�mentation. */
double calculerAngle(float x, float y)
{
    double angle = 0.;

    if (x == 0.f)
    {
        angle = math::Pi / 2.;

        if (y < 0.f)
        {
            angle *= 3.;
        }
    }
    else
    {
        angle = std::atan(y / x);

        if (x < 0.f)
        {
            angle += math::Pi;
        }
        else
        {
            if (y < 0.f)
            {
                angle += 2. * math::Pi;
            }
        }
    }

    return angle;
}

// Constructeur de conversion depuis Cartesien.
Polaire::Polaire(const Cartesien & cartesien)
{
    rayon_ = std::sqrt(cartesien.getX() * cartesien.getX() + cartesien.getY() * cartesien.getY());

    if (rayon_ != 0.)
    {
        angle_ = calculerAngle(cartesien.getX(), cartesien.getY());
    }
    else
    {
        // Si le rayon est �gal � 0, l'angle peut prendre n'importe quelle
        // valeur. On donne arbitrairement la valeur 0.
        angle_ = 0.;
    }
}


float Polaire::getRayon() const
{
    return rayon_;
}

double Polaire::getAngle() const
{
    return angle_;
}


Cartesien Polaire::enCartesien() const
{
    // Reutilisation du constructeur de conversion de Cartesien.
    return Cartesien(*this);
}


// Ecriture
std::ostream & Polaire::afficher(std::ostream & sortie) const
{
    return sortie << "(rayon,angle) = (" << rayon_ << ',' << angle_ << ')';
}


// Lecture
/**
 * @TODO: Corriger cette impl�mentation qui r�cup�re les coordonn�es en
 * ignorant les autres caract�res.
 */
std::istream & Polaire::lire(std::istream & entree)
{
    char c;
    return entree >> c >> rayon_ >> c >> angle_ >> c;
}


}} // namespace isima::espace
