#ifndef CARTESIEN_H_INCLUDED
#define CARTESIEN_H_INCLUDED

#include <iostream>

#include "Point.hpp"

namespace isima { namespace espace {


class Polaire;

/* Remarque : Encore une fois, une d�claration anticip�e est suffisante. */

/** Classe representant un point en coordonnees cartesiennes. */
class Cartesien : public Point
{
  public:

    /** 
     * Constructeur par defaut.
     * Initialise x et y a 0.
     */
    Cartesien();

    /** 
     * Constructeur.
     * Initialise l'abcisse et l'ordonnee avec les valeurs passees en parametre.
     * @param x Abcisse.
     * @param x Ordonne.
     */
    Cartesien(float x, float y);

    /**
     * Constructeur de conversion depuis un polaire.
     * @param p Polaire a convertir.
     */
    Cartesien(const Polaire &);


    /** Retourne l'abcisse du point. */
    float getX() const;

    /** Retourne l'ordonnee du point. */
    float getY() const;


    Cartesien enCartesien() const;


    /**
     * Affiche le point sous la forme (x,y) = (<x>,<y>).
     * @param sortie Le flux sur lequel afficher le point.
     */
    std::ostream & afficher(std::ostream & sortie) const;

    /** 
     * Lit le point sous la forme (<x>,<y>).
     * @param entree Le flux sur lequel lire le point.
     */
    std::istream & lire(std::istream & entree);


  private:

    float x_; /// Abcisse.
    float y_; /// Ordonnee.
};


}} // namespace isima::espace

#endif // CARTESIEN_H_INCLUDED
