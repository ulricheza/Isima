#ifndef PI_H_INCLUDED
#define PI_H_INCLUDED

/* Comme pi n'est pas d�fini par la biblioth�que standard, je d�finis ma propre
constante. Dans un code professionnel, j'utiliserais soit M_PI, d�finie par 
certaines impl�mentations dans <cmath> (au prix de la portabilit� du code),
soit une biblioth�que tierce (Boost.Math par exemple). */

#include <cmath>

namespace isima { namespace math {

/** Constante pi. */
const double Pi = std::atan(1.0) * 4;

}} // namespace isima::math

#endif // PI_H_INCLUDED