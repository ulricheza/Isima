#ifndef POLAIRE_H_INCLUDED
#define POLAIRE_H_INCLUDED

#include <iostream>

#include "Point.hpp"

namespace isima { namespace espace {


class Cartesien;

/** Classe representant un point en coordonnes polaires. */
class Polaire : public Point
{
  public:

    /**
     * Constructeur par defaut.
     * Initialise le rayon et l'angle a 0.
     */
    Polaire();

    /**
     * Constructeur.
     * Initialise le rayon et l'angle avec les valeurs passees en parametre.
     * @param rayon Coordonn�e radiale du point.
     * @param angle Coordonn�e angulaire du point.
     */
    Polaire(float rayon, double angle);

    /**
     * Constructeur de conversion depuis un cartesien.
     * @param c Cartesien a convertir.
     */
    Polaire(const Cartesien &);


    /** Retourne la coordonn�e radiale du point. */
    float getRayon() const;

    /** Retourne la coordonn�e angulaire du point. */
    double getAngle() const;


    Cartesien enCartesien() const;


    /**
     * Affiche le point sous la forme (rayon,angle) = (<rayon>,<angle>).
     * @param sortie Le flux sur lequel afficher le point.
     */
    std::ostream & afficher(std::ostream & sortie) const;

    /**
     * Lit le point sous la forme (<rayon>,<angle>).
     * @param entree Le flux sur lequel lire le point.
     */
    std::istream & lire(std::istream & entree);


  private:

    float rayon_; /**< Coordonn�e radiale. */
    double angle_; /**< Coordonn�e angulaire. */

};


}} // namespace isima::espace

#endif // POLAIRE_H_INCLUDED
