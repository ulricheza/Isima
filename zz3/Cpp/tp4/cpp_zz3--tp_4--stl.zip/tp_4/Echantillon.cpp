#include "Echantillon.hpp"

#include <algorithm>

#include "Valeur.hpp"


void Echantillon::ajouterValeur( const Valeur & valeur )
{
    valeurs_.push_back( valeur );
}


const Valeur & Echantillon::getMinimum( ) const
{
    return *std::min_element( valeurs_.begin(), valeurs_.end() );
}


const Valeur & Echantillon::getMaximum( ) const
{
    return *std::max_element( valeurs_.begin(), valeurs_.end() );
}


const Valeur & Echantillon::at( unsigned int index ) const
{
    return valeurs_[ index ];
}


unsigned int Echantillon::taille( ) const
{
    return valeurs_.size();
}