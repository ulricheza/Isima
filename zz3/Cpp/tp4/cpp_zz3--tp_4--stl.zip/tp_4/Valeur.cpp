#include "Valeur.hpp"

Valeur::Valeur( const std::string & etudiant, float note )
  : etudiant_( etudiant ), note_( note )
{
}


float Valeur::getNote( ) const
{
    return note_;
}


const std::string & Valeur::getEtudiant( ) const
{
    return etudiant_;
}


bool operator<( const Valeur & v1, const Valeur & v2 )
{
    return v1.getNote() < v2.getNote();
}