#ifndef VALEUR_HPP
#define VALEUR_HPP

#include <string>

class Valeur
{
  public:
 
    Valeur( const std::string & etudiant, float note = 0 );

    float               getNote( )     const;
    const std::string & getEtudiant( ) const;

  private:
    
    const float       note_;
    const std::string etudiant_;
};


bool operator<( const Valeur & v1, const Valeur & v2 );


#endif
