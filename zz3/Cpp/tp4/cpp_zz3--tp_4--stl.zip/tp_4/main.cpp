#include <iostream>

#include <cstdlib>

#include "Echantillon.hpp"
#include "Histogramme.hpp"
#include "Valeur.hpp"

struct ComparateurParQuantite
{
    bool operator()( const Classe & c1, const Classe & c2 )
    {
        if ( c1.getQuantite() == c2.getQuantite() )
        {
            return c1 < c2;
        }

        return c1.getQuantite() > c2.getQuantite();
    }
};


int main()
{
    srand( 0u );
    
    Echantillon echantillon;

    for ( unsigned int nbValeurs = 0 ; nbValeurs < 20 ; ++nbValeurs )
    {
        echantillon.ajouterValeur( Valeur( "toto", static_cast< float >( rand() ) / RAND_MAX * 20.0f ) );
    }

    {
        Histogramme<> histo( 0.0f, 20.0f, 10u, echantillon );

        histo.afficher( std::cout );

        histo.ajouterValeur( Valeur( "toto", 11.5f ) );

        std::cout << '\n' << "-----------------------------" << '\n' << '\n';
        histo.afficher( std::cout );

        Echantillon petitEchantillon;

        petitEchantillon.ajouterValeur( Valeur( "toto", 0.5f ) );
        petitEchantillon.ajouterValeur( Valeur( "toto", 1.5f ) );
        petitEchantillon.ajouterValeur( Valeur( "toto", 0.2f ) );
        petitEchantillon.ajouterValeur( Valeur( "toto", 2.0f ) );

        histo.ajouterEchantillon( petitEchantillon );
    
        std::cout << '\n' << "-----------------------------" << '\n' << '\n';
        histo.afficher( std::cout );

        std::cin.ignore();
    }

    std::cout << '\n' << '\n' << "----------2eme test--------------" << '\n' << '\n';

    {
        Histogramme< ComparateurParQuantite > histo( 0.0f, 20.0f, 10u, echantillon );

        histo.afficher( std::cout );

        histo.ajouterValeur( Valeur( "toto", 11.5f ) );

        std::cout << '\n' << "-----------------------------" << '\n' << '\n';
        histo.afficher( std::cout );

        Echantillon petitEchantillon;

        petitEchantillon.ajouterValeur( Valeur( "toto", 0.5f ) );
        petitEchantillon.ajouterValeur( Valeur( "toto", 1.5f ) );
        petitEchantillon.ajouterValeur( Valeur( "toto", 0.2f ) );
        petitEchantillon.ajouterValeur( Valeur( "toto", 2.0f ) );

        histo.ajouterEchantillon( petitEchantillon );
    
        std::cout << '\n' << "-----------------------------" << '\n' << '\n';
        histo.afficher( std::cout );

        std::cin.ignore();
    }
}