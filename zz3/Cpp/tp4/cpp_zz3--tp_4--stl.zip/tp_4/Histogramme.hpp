#ifndef HISTOGRAMME_HPP
#define HISTOGRAMME_HPP

#include <map>
#include <ostream>
#include <set>

#include "Classe.hpp"

class Echantillon;
class Valeur;

template < typename Compare = std::less< Classe > >
class Histogramme
{
  public:

    Histogramme( float borneMin, float borneMax, unsigned int nbClasses, Compare comp = Compare() );
    Histogramme( float borneMin, float borneMax, unsigned int nbClasses, const Echantillon & echantillon, Compare comp = Compare() );

    void ajouterEchantillon( const Echantillon & echantillon );
    void ajouterValeur( const Valeur & valeur );

    void afficher( std::ostream & stream ) const;

  private:

    typedef std::set< Classe, Compare >              ConteneurDeClasses;
    typedef std::multimap< Classe, Valeur, Compare > MapClasseValeurs;

    void creerClasses( float borneMin, float borneMax, unsigned int nbClasses );

    ConteneurDeClasses classes_;
    MapClasseValeurs   map_;
};


#include "Histogramme.tpp"


#endif