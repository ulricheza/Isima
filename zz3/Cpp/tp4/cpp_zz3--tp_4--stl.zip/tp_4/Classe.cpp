#include "Classe.hpp"

Classe::Classe( float borneMin, float borneMax, unsigned int quantite )
  : borneMin_( borneMin ), borneMax_( borneMax ), quantite_( quantite )
{
}


float Classe::getBorneMin( ) const
{
    return borneMin_;
}


float Classe::getBorneMax( ) const
{
    return borneMax_;
}


unsigned int Classe::getQuantite( ) const
{
    return quantite_;
}


bool Classe::comprend( float element ) const
{
    return ( element >= borneMin_ ) && ( element < borneMax_ );
}


 void Classe::incrementerQuantite( )
 {
     ++quantite_;
 }


 bool operator<( const Classe & c1, const Classe & c2 )
 {
     return c1.getBorneMin() < c2.getBorneMin();
 }