#ifndef ECHANTILLON_HPP
#define ECHANTILLON_HPP

#include <vector>

class Valeur;

class Echantillon
{
  public:

    void ajouterValeur( const Valeur & valeur );

    const Valeur & getMinimum( ) const;
    const Valeur & getMaximum( ) const;

    const Valeur & at( unsigned int index ) const;
    unsigned int taille( ) const;

  private:

    std::vector< Valeur > valeurs_;
};


#endif
