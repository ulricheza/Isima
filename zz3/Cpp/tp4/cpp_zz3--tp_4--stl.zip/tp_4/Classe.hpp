#ifndef CLASSE_HPP
#define CLASSE_HPP

class Classe
{
  public:

    Classe( float borneMin, float borneMax, unsigned int quantite = 0 );

    float        getBorneMin( ) const;
    float        getBorneMax( ) const;
    unsigned int getQuantite( ) const;


    bool comprend( float element ) const;
    void incrementerQuantite( );

  private:

    float        borneMin_;
    float        borneMax_;
    unsigned int quantite_;
};


bool operator<( const Classe & c1, const Classe & c2 );


#endif
