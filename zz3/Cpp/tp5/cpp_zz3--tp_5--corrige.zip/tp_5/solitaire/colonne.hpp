// Gardien //---------------------------------------------------------------------------------------
#ifndef _COLONNE_HPP_
#define _COLONNE_HPP_

// Entetes //---------------------------------------------------------------------------------------
#include <vector>
#include <solitaire/carte.hpp>

// Types //-----------------------------------------------------------------------------------------
typedef std::vector<Carte *> Main;

// Classe  C o l o n n e //-------------------------------------------------------------------------
class Colonne {
 //----------------------------------------------------------------------------------------Attributs
 protected: std::vector<Carte *> pile_;
 //---------------------------------------------------------------------------------------Accesseurs
 public: bool    estVide(void) const { return pile_.empty(); }
 public: size_t  getTaille(void) const { return pile_.size(); }
 public: Carte * getSommet(void) { return (estVide() ? 0 : pile_.back()); }

 public: Carte * getCarte(size_t indice) const
 { return (indice>=getTaille() ? 0 : pile_[indice]); }
 //-------------------------------------------------------------------------------Methodes publiques
 public: void ajouter(Main &);
 public: void ajouter(Carte * carte) { pile_.push_back(carte); }
 public: void retirer(size_t,Main &);
};

// Fin //-------------------------------------------------------------------------------------------
#endif
