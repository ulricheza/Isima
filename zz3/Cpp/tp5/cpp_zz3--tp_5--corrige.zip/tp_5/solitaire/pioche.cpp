// Entetes //---------------------------------------------------------------------------------------
#include <solitaire/pioche.hpp>

// Implementation  P i o c h e //-------------------------------------------------------------------

//-------------------------------------------------------------------------------------------Ajouter
void Pioche::ajouter(Carte * carte) {
 cachees_.push(carte);
 cachees_.top()->setCachee(true);
}

//---------------------------------------------------------------------------------------------Tirer
bool Pioche::tirer(void) {
 if (estVide()) return false;
 if (toutRetourne()) while (!rienRetourne()) ajouter(retirer());

 retournees_.push(cachees_.top());
 cachees_.pop();
 retournees_.top()->setCachee(false);

 return true;
}

//-------------------------------------------------------------------------------------------Retirer
Carte * Pioche::retirer(void) {
 if (rienRetourne()) return 0;

 Carte * carte = retournees_.top();
 retournees_.pop();

 return carte;
}

// Fin //-------------------------------------------------------------------------------------------
