// Entetes //---------------------------------------------------------------------------------------
#include <cstdlib>
#include <solitaire/croupier_fairplay.hpp>

// Implementation  C r o u p i e r F a i r p l a y //-----------------------------------------------

//------------------------------------------------------------------------------------------Melanger
void CroupierFairplay::melanger(Paquet & paquet) const {
 Plateau plateau;
 Carte * carte;
 size_t i;
 size_t j;
 std::vector<size_t> colonnes;
 std::vector<size_t> docks;
 size_t colonne;
 size_t dock;
 std::vector<size_t> positions;
 std::vector<size_t> numeros;

 // Placement sur les docks //
 for (i=0; i<4; ++i) {
  for (j=0; j<13; ++j) {
   carte=paquet.getSuivante();
   carte->setCachee(false);
   plateau.getDock(i).ajouter(carte);
  }
 }

 // Placement au hasard sur les colonnes //
 for (i=0; i<7; ++i) colonnes.push_back(i);
 for (i=0; i<4; ++i) docks.push_back(i);

 for (i=0; i<52; ++i) {
  dock=std::rand()%docks.size();
  carte=plateau.getDock(docks[dock]).retirer();

  if (plateau.getDock(docks[dock]).estVide()) {
   docks[dock]=docks.back();
   docks.pop_back();
  }

  if (colonnes.size()==0) {
   colonne=rand()%7;
   plateau.getColonne(colonne).ajouter(carte);
  }
  else {
   colonne=rand()%colonnes.size();
   plateau.getColonne(colonnes[colonne]).ajouter(carte);

   if (plateau.getColonne(colonnes[colonne]).getTaille()==7) {
    colonnes[colonne]=colonnes.back();
    colonnes.pop_back();
   }
  }
 }

 // Deplacement du surplus dans la pioche //
 for (i=0; i<7; ++i) {
  while (plateau.getColonne(i).getTaille()>i+1) {
   plateau.getColonne(i).retirer(plateau.getColonne(i).getTaille()-1,plateau.getMain());
   plateau.getPioche().ajouter(plateau.getMain().back());
   plateau.getMain().clear();
  }
 }

 // Deplacement des cartes dans la pioche //
 while (i>0) {
  j=i--;

  while (j>0) {
   --j;
   plateau.getColonne(i).retirer(j,plateau.getMain());
   plateau.getPioche().ajouter(plateau.getMain().back());
   plateau.getMain().clear();
  }
 }

 // Replacement du paquet //
 for (i=0; i<52; ++i) {
  numeros.push_back(i);
  positions.push_back(i);
 }

 i=0;

 while (i<52) {
  plateau.getPioche().tirer();
  carte=plateau.getPioche().retirer();
  j=positions[carte->getNumero()];

  paquet.permuter(j,i);

  positions[numeros[i]]=j;
  positions[carte->getNumero()]=i;

  numeros[j]=numeros[i];
  numeros[i]=carte->getNumero();
  ++i;
 }

 paquet.reinitialiser();
}

// Fin //-------------------------------------------------------------------------------------------
