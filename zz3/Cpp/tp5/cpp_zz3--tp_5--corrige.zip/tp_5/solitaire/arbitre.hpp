// Gardien //---------------------------------------------------------------------------------------
#ifndef _ARBITRE_HPP_
#define _ARBITRE_HPP_

// Entetes //---------------------------------------------------------------------------------------
#include <solitaire/plateau.hpp>

// Declarations fonctions //------------------------------------------------------------------------
bool operator < (const Carte &,const Carte &);

// Classe  A r b i t r e //-------------------------------------------------------------------------
class Arbitre {
 //----------------------------------------------------------------------------------------Attributs
 protected: Plateau * plateau_;
 protected: size_t    precedent_;
 protected: bool      retournee_;
 //---------------------------------------------------------------------------------------Accesseurs
 public: void setPlateau(Plateau & plateau) { plateau_=&plateau; }
 //------------------------------------------------------------------------------------Constructeurs
 public: Arbitre(void) : plateau_(0),precedent_(999),retournee_(false) {}
 //-------------------------------------------------------------------------------Methodes publiques
 public: bool retirerColonne(size_t,size_t);
 public: bool deposerColonne(size_t);
 public: bool piocher(void);
 public: bool retirerPioche(void);
 public: bool deposerDock(size_t);
 public: bool annuler(void);
};

//---------------------------------------------------------------------------------------Operateur <
inline bool operator < (const Carte & c1,const Carte & c2) {
 if (c1.estRouge() && c2.estRouge()) return false;
 if (c1.estNoir() && c2.estNoir()) return false;

 return ((int)c1.getValeur()+1 == (int)c2.getValeur());
}

// Fin //-------------------------------------------------------------------------------------------
#endif
