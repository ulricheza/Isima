// Entetes //---------------------------------------------------------------------------------------
#include <solitaire/colonne.hpp>

// Implementation  C o l o n n e //-----------------------------------------------------------------

//-------------------------------------------------------------------------------------------Ajouter
void Colonne::ajouter(Main & main) {
 while (main.size()>0) {
  pile_.push_back(main.back());
  main.pop_back();
 }
}

//-------------------------------------------------------------------------------------------Retirer
void Colonne::retirer(size_t indice,Main & main) {
 main.clear();
 if (indice>=getTaille()) return;

 while (pile_.size()>indice) {
  main.push_back(pile_.back());
  pile_.pop_back();
 }
}

// Fin //-------------------------------------------------------------------------------------------
