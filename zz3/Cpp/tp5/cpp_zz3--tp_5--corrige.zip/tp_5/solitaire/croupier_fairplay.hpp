// Gardien //---------------------------------------------------------------------------------------
#ifndef _CROUPIER_FAIRPLAY_HPP_
#define _CROUPIER_FAIRPLAY_HPP_

// Entetes //---------------------------------------------------------------------------------------
#include <solitaire/croupier.hpp>

// Classe  C r o u p i e r F a i r p l a y //-------------------------------------------------------
class CroupierFairplay : public Croupier {
 //-------------------------------------------------------------------------------Methodes publiques
 public: void melanger(Paquet &) const;
};

// Fin //-------------------------------------------------------------------------------------------
#endif
