// Entetes //---------------------------------------------------------------------------------------
#include <solitaire/croupier.hpp>

// Implementation  C r o u p i e r //---------------------------------------------------------------

//----------------------------------------------------------------------------------------Distribuer
void Croupier::distribuer(Paquet & paquet,Plateau & plateau) const {
 Carte * carte;

 for (int i=0; i<7; ++i)
  for (int j=0; j<=i; ++j) {
   carte=paquet.getSuivante();
   carte->setCachee(j!=i);
   plateau.getColonne(i).ajouter(carte);
  }

 while ((carte=paquet.getSuivante())!=0) plateau.getPioche().ajouter(carte);
}

// Fin //-------------------------------------------------------------------------------------------
