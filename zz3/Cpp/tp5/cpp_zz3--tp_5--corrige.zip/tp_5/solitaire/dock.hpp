// Gardien //---------------------------------------------------------------------------------------
#ifndef _DOCK_HPP_
#define _DOCK_HPP_

// Entetes //---------------------------------------------------------------------------------------
#include <stack>
#include <solitaire/carte.hpp>

// Classe  D o c k //-------------------------------------------------------------------------------
class Dock {
 //----------------------------------------------------------------------------------------Attributs
 protected: std::stack<Carte *> pile_;
 //---------------------------------------------------------------------------------------Accesseurs
 public: bool    estVide(void) const { return pile_.empty(); }
 public: Carte * getSommet(void) const { return (estVide() ? 0 : pile_.top()); }
 //-------------------------------------------------------------------------------Methodes publiques
 public: void    ajouter(Carte * carte) { pile_.push(carte); }
 public: Carte * retirer(void);
};

// Fin //-------------------------------------------------------------------------------------------
#endif
