// Entetes //---------------------------------------------------------------------------------------
#include <solitaire/solitaire.hpp>

// Implementation  S o l i t a i r e //-------------------------------------------------------------

//--------------------------------------------------------------------------------------Constructeur
Solitaire::Solitaire(Arbitre & arbitre,const Croupier & croupier)
: arbitre_(arbitre),croupier_(croupier),paquet_(),plateau_(),controleur_(0) {}

//---------------------------------------------------------------------------------------Initialiser
void Solitaire::initialiser(void) {
 croupier_.melanger(paquet_);
 croupier_.distribuer(paquet_,plateau_);
 arbitre_.setPlateau(plateau_);
 if (controleur_) controleur_->rafraichir();
}

// Fin //-------------------------------------------------------------------------------------------
