// Gardien //---------------------------------------------------------------------------------------
#ifndef _CROUPIER_SIMPLE_HPP_
#define _CROUPIER_SIMPLE_HPP_

// Entetes //---------------------------------------------------------------------------------------
#include <cstdlib>
#include <solitaire/croupier.hpp>

// Classe  C r o u p i e r S i m p l e //-----------------------------------------------------------
class CroupierSimple : public Croupier {
 //----------------------------------------------------------------------------------------Attributs
 protected: size_t force_;
 //-------------------------------------------------------------------------------Methodes protegees
 protected: size_t tirerCarte(void) const { return (std::rand()%52); }
 //------------------------------------------------------------------------------------Constructeurs
 public: CroupierSimple(size_t force = 100) : force_(force) {}
 //-------------------------------------------------------------------------------Methodes publiques
 public: void melanger(Paquet &) const;
};

// Fin //-------------------------------------------------------------------------------------------
#endif
