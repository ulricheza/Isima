// Gardien //---------------------------------------------------------------------------------------
#ifndef _CROUPIER_HPP_
#define _CROUPIER_HPP_

// Entetes //---------------------------------------------------------------------------------------
#include <solitaire/paquet.hpp>
#include <solitaire/plateau.hpp>

// Classe  C r o u p i e r //-----------------------------------------------------------------------
class Croupier {
 //--------------------------------------------------------------------------------------Destructeur
 public: virtual ~Croupier(void) {}
 //-------------------------------------------------------------------------------Methodes publiques
 public: virtual void melanger(Paquet &) const = 0;
 public: virtual void distribuer(Paquet &,Plateau &) const;
};

// Fin //-------------------------------------------------------------------------------------------
#endif
