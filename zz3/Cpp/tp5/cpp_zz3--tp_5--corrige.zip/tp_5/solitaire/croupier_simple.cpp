// Entetes //---------------------------------------------------------------------------------------
#include <solitaire/croupier_simple.hpp>

// Implementation  C r o u p i e r S i m p l e //---------------------------------------------------

//------------------------------------------------------------------------------------------Melanger
void CroupierSimple::melanger(Paquet & paquet) const {
 for (size_t i=0; i<force_; ++i) paquet.permuter(tirerCarte(),tirerCarte());
}

// Fin //-------------------------------------------------------------------------------------------
