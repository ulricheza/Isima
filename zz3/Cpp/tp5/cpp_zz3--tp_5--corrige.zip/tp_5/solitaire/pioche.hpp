// Gardien //---------------------------------------------------------------------------------------
#ifndef _PIOCHE_HPP_
#define _PIOCHE_HPP_

// Entetes //---------------------------------------------------------------------------------------
#include <stack>
#include <solitaire/carte.hpp>

// Classe  P i o c h e //---------------------------------------------------------------------------
class Pioche {
 //----------------------------------------------------------------------------------------Attributs
 protected: std::stack<Carte *> cachees_;
 protected: std::stack<Carte *> retournees_;
 //---------------------------------------------------------------------------------------Accesseurs
 public: bool    rienRetourne(void) const { return retournees_.empty(); }
 public: bool    toutRetourne(void) const { return cachees_.empty(); }
 public: bool    estVide(void) const { return cachees_.empty() && retournees_.empty(); }
 public: Carte * getVisible(void) const { return (rienRetourne() ? 0 : retournees_.top()); }
 public: Carte * getProchaine(void) const { return (toutRetourne() ? 0 : cachees_.top()); }
 //-------------------------------------------------------------------------------Methodes publiques
 public: void    ajouter(Carte *);
 public: bool    tirer(void);
 public: Carte * retirer(void);
};

// Fin //-------------------------------------------------------------------------------------------
#endif
