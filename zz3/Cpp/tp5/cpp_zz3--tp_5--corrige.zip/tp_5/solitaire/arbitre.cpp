// Entetes //---------------------------------------------------------------------------------------
#include <solitaire/arbitre.hpp>

// Implementation  A r b i t r e //-----------------------------------------------------------------

//------------------------------------------------------------------------------------RetirerColonne
bool Arbitre::retirerColonne(size_t colonne,size_t ligne) {
 if (!plateau_) return false;
 if (!plateau_->getMain().empty()) return false;

 const Carte * carte = plateau_->getColonne(colonne).getCarte(ligne);

 if (carte==0 || carte->estCachee()) return false;

 plateau_->getColonne(colonne).retirer(ligne,plateau_->getMain());
 precedent_=colonne;

 if (!plateau_->getColonne(colonne).estVide()
     && plateau_->getColonne(colonne).getSommet()->estCachee()) {
  plateau_->getColonne(colonne).getSommet()->setCachee(false);
  retournee_=true;
 }
 else retournee_=false;

 return true;
}

//------------------------------------------------------------------------------------DeposerColonne
bool Arbitre::deposerColonne(size_t colonne) {
 if (!plateau_) return false;
 if (plateau_->getMain().empty()) return false;

 Carte * carte1 = plateau_->getMain().back();
 const Carte * carte2 = plateau_->getColonne(colonne).getSommet();
 bool ok = false;

 if (carte2==0) ok=(carte1->getValeur()==Carte::ROI);
 else ok=(*carte1 < *carte2);

 if (ok) {
  plateau_->getColonne(colonne).ajouter(plateau_->getMain());
  precedent_=99;
 }

 return ok;
}

//---------------------------------------------------------------------------------------DeposerDock
bool Arbitre::deposerDock(size_t colonne) {
 if (plateau_->getMain().size()!=1) return false;

 Carte * carte1 = plateau_->getMain().back();
 const Carte * carte2 = plateau_->getDock(colonne).getSommet();
 bool ok = false;

 if (carte2==0)
  ok=(carte1->getValeur()==Carte::AS);
 else if (carte2->getFamille()==carte1->getFamille())
  ok=(int(carte2->getValeur()) == int(carte1->getValeur())-1);

 if (ok) {
  plateau_->getDock(colonne).ajouter(plateau_->getMain().back());
  plateau_->getMain().pop_back();
  precedent_=99;
 }

 return ok;
}

//-------------------------------------------------------------------------------------------Piocher
bool Arbitre::piocher(void) {
 if (!plateau_) return false;
 if (plateau_->getPioche().estVide()) return false;

 plateau_->getPioche().tirer();
 precedent_=0;
 return true;
}

//-------------------------------------------------------------------------------------RetirerPioche
bool Arbitre::retirerPioche(void) {
 if (!plateau_) return false;
 if (plateau_->getPioche().rienRetourne()) return false;

 plateau_->getMain().push_back(plateau_->getPioche().retirer());
 precedent_=101;
 return true;
}

//-------------------------------------------------------------------------------------------Annuler
bool Arbitre::annuler(void) {
 if (!plateau_) return false;

 if (precedent_==101) {
  plateau_->getPioche().ajouter(plateau_->getMain().back());
  plateau_->getPioche().tirer();
  plateau_->getMain().pop_back();
  precedent_=99;
  return true;
 }
 else if (precedent_<7) {
  if (retournee_==true) plateau_->getColonne(precedent_).getSommet()->setCachee(true);
  plateau_->getColonne(precedent_).ajouter(plateau_->getMain());
  precedent_=99;
  return true;
 }

 return false;
}

// Fin //-------------------------------------------------------------------------------------------
