// Entetes //---------------------------------------------------------------------------------------
#include <QApplication>
#include <controleur_graphique.hpp>

// Implementation  V u e G r a p h i q u e //-------------------------------------------------------

//--------------------------------------------------------------------------------------Constructeur
ControleurGraphique::ControleurGraphique(Solitaire & solitaire,QApplication & appli)
: QObject(),Controleur(solitaire),appli_(appli),fenetre_() {}

//----------------------------------------------------------------------------------TransformerCarte
ControleurGraphique::carte_t ControleurGraphique::transformerCarte(const Carte * carte) {
 if (carte->estCachee()) return carte_t(Valeur::dos_v,Couleur::dos_c);

 return carte_t(Valeur::Enum(carte->getValeur()),Couleur::Enum(carte->getFamille()));
}

//------------------------------------------------------------------------------------------Demarrer
void ControleurGraphique::demarrer(void) {
 fenetre_.show();

 QObject::connect(&fenetre_,SIGNAL(demandeDeplacement(const Zone::Enum &,
                                                      const Zone::Enum &,
                                                      const int &)),
                  this,SLOT(deplacerCartes(const Zone::Enum &,
                                           const Zone::Enum &,
                                           const int &)));

 solitaire_.initialiser();
 appli_.exec();
}

//----------------------------------------------------------------------------------------Rafraichir
void ControleurGraphique::rafraichir(void) {
 Carte *        carte;
 QList<carte_t> cartes;

 const Plateau & plateau = solitaire_.getPlateau();

 if ((carte=plateau.getPioche().getProchaine())) cartes << transformerCarte(carte);
 fenetre_.miseAJourPioche(cartes);
 cartes.clear();

 if ((carte=plateau.getPioche().getVisible())) cartes << transformerCarte(carte);
 fenetre_.miseAJourDefausse(cartes);
 cartes.clear();

 for (size_t i=0; i<4; ++i) {
  if ((carte=plateau.getDock(i).getSommet())) cartes << transformerCarte(carte);
  fenetre_.miseAJourDock(i,cartes);
  cartes.clear();
 }

 for (size_t i=0; i<7; ++i) {
  for (size_t j=0; j<plateau.getColonne(i).getTaille(); ++j)
   cartes << transformerCarte(plateau.getColonne(i).getCarte(j));

   fenetre_.miseAJourColonne(i,cartes);
   cartes.clear();
 }
}

//------------------------------------------------------------------------------------DeplacerCartes
void ControleurGraphique::deplacerCartes(const Zone::Enum & depart,const Zone::Enum & arrivee,
                                         const int & nbCarte) {
 size_t i;

 bool deplace = false;
 bool ok      = false;

 Arbitre &       arbitre = solitaire_.getArbitre();
 const Plateau & plateau = solitaire_.getPlateau();

 if (depart==Zone::pioche) {
  if (arrivee==Zone::defausse) ok=arbitre.piocher();
 }
 else if (depart==Zone::defausse) {
  ok=arbitre.retirerPioche();
  deplace=ok;
 }
 else if (depart>=Zone::colonne1 && depart<=Zone::colonne7) {
  i=size_t(depart)-size_t(Zone::colonne1);
  ok=arbitre.retirerColonne(i,plateau.getColonne(i).getTaille()-nbCarte);
  deplace=ok;
 }

 if (deplace) {
  if (arrivee>=Zone::dock1 && arrivee<=Zone::dock4) {
   i=size_t(arrivee)-size_t(Zone::dock1);
   ok=arbitre.deposerDock(i);
  }
  else if (arrivee>=Zone::colonne1 && arrivee<=Zone::colonne7) {
   i=size_t(arrivee)-size_t(Zone::colonne1);
   ok=arbitre.deposerColonne(i);
  }
  else ok=false;

  if (!ok) arbitre.annuler();
 }

 if (ok) rafraichir();
 else fenetre_.afficherErreur("Deplacement impossible");
}

// Fin //-------------------------------------------------------------------------------------------
