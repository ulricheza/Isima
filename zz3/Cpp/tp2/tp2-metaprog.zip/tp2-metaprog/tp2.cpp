#include <cmath>
#include <iostream>

#include "cosinus.hpp"
#include "exponentielle.hpp"
#include "factorielle.hpp"
#include "puissance.hpp"
#include "sinus.hpp"


// Utilisez plut�t une biblioth�que de tests unitaires...
#define ASSERT_EQUAL( valueObtained, valueExpected, errorMsg ) \
    ++nbTotalTests; \
    if ( (valueObtained) != (valueExpected) ) \
    { \
        std::cerr << '!' << errorMsg << "!\n" << \
                     "  Expected: " << valueExpected << '\n' << \
                     "  Obtained: " << valueObtained << std::endl; \
        ++nbFailedTests; \
    }


#define ASSERT_ALMOST_EQUAL( valueObtained, valueExpected, errorMsg ) \
    ++nbTotalTests; \
    if ( std::fabs( (valueObtained) - (valueExpected) ) > 0.001 ) \
    { \
        std::cerr << '!' << errorMsg << "!\n" << \
                     "  Expected: " << valueExpected << '\n' << \
                     "  Obtained: " << valueObtained << std::endl; \
        ++nbFailedTests; \
    }


int nbFailedTests = 0;
int nbTotalTests = 0;


using namespace isima::metaprog;


void testCosinus()
{
    ASSERT_ALMOST_EQUAL( Cosinus<1>::evaluer(0.0), std::cos(0.0), "cos(0) failed" )
    ASSERT_ALMOST_EQUAL( Cosinus<4>::evaluer(-2.0), std::cos(-2.0), "cos(-2) failed" )
    ASSERT_ALMOST_EQUAL( Cosinus<3>::evaluer(1.0), std::cos(1.0), "cos(1) failed" )
}

void testExponentielle()
{
    ASSERT_ALMOST_EQUAL( Exponentielle<4>::evaluer(0.0), std::exp(0.0), "exp(0) failed" )
    ASSERT_ALMOST_EQUAL( Exponentielle<10>::evaluer(-2.5), std::exp(-2.5), "exp(-2.5) failed" )
    ASSERT_ALMOST_EQUAL( Exponentielle<7>::evaluer(1.4), std::exp(1.4), "exp(1.4) failed" )
}

void testFactorielle()
{
    ASSERT_EQUAL( Factorielle<0>::valeur, 1, "0! failed" )
    ASSERT_EQUAL( Factorielle<10>::valeur, 3628800, "10! failed" )
}

void testPuissance()
{
    ASSERT_ALMOST_EQUAL( Puissance<0>::evaluer(7.0), 1.0, "7^0 failed" )
    ASSERT_ALMOST_EQUAL( Puissance<3>::evaluer(8.0), 512.0, "8^3 failed" )
    ASSERT_ALMOST_EQUAL( Puissance<9>::evaluer(0.0), 0.0, "0^9 failed" )
}

void testSinus()
{
    ASSERT_ALMOST_EQUAL( Sinus<3>::evaluer(0.0), std::sin(0.0), "sin(0) failed" )
    ASSERT_ALMOST_EQUAL( Sinus<5>::evaluer(-2.0), std::sin(-2.0), "sin(-2) failed" )
    ASSERT_ALMOST_EQUAL( Sinus<4>::evaluer(1.0), std::sin(1.0), "sin(1) failed" )
}

int main()
{
    testCosinus();
    testExponentielle();
    testFactorielle();
    testPuissance();
    testSinus();

    if (nbFailedTests == 0)
    {
        std::cout << "All tests (" << nbTotalTests << ") passed." << std::endl;
        return EXIT_SUCCESS;
    }
    else
    {
        std::cout << nbFailedTests << " tests failed." << std::endl;
        std::cout << nbTotalTests - nbFailedTests << " tests succeeded." << std::endl;
        return EXIT_FAILURE;
    }
}