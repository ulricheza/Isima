#ifndef FACTORIELLE_H_INCLUDED
#define FACTORIELLE_H_INCLUDED

namespace isima { namespace metaprog {

// Cas r�cursif
template <short N>
struct Factorielle
{
    // fac(n) = n * fac(n-1)
    static const unsigned long int valeur = N * Factorielle<N - 1>::valeur;
};

// Cas de base
template <>
struct Factorielle<0>
{
    // fac(0) = 1
    static const unsigned long int valeur = 1;
};


}} // namespace isima::metaprog

#endif // FACTORIELLE_H_INCLUDED