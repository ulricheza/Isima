#ifndef PUISSANCE_H_INCLUDED
#define PUISSANCE_H_INCLUDED

namespace isima { namespace metaprog {

// Cas r�cursif
template <int N>
struct Puissance
{
    // x^n = x * x^(n-1)
    static const double evaluer(double x)
	{
	    return x * Puissance<N - 1>::evaluer(x);
	}
};

// Cas de base
template <>
struct Puissance<0>
{
    // x^0 = 1
    static const double evaluer(double x)
	{
		return 1;
	}
};


}} // namespace isima::metaprog


#endif // PUISSANCE_H_INCLUDED