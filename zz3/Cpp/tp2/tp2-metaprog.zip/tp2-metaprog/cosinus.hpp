#ifndef COSINUS_H_INCLUDED
#define COSINUS_H_INCLUDED

#include "factorielle.hpp"
#include "puissance.hpp"

namespace isima { namespace metaprog {

// Cas r�cursif
template <short Degre>
struct Cosinus
{
    // cos[n](x) = (-1)^n * x^(2n) / (2n)!
    static double evaluer(double x)
	{
	    double terme = Puissance<Degre>::evaluer(-1) * 
                       Puissance<2 * Degre>::evaluer(x) / 
                       Factorielle<2 * Degre>::valeur;
	    return terme + Cosinus<Degre - 1>::evaluer(x);
	}
};

// Cas de base
template <>
struct Cosinus<0>
{
    // cos[0](x) = 0
    static double evaluer(double x)
	{
	    return 1.;
	}
};


}} // namespace isima::metaprog

#endif // COSINUS_H_INCLUDED