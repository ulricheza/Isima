#ifndef SINUS_H_INCLUDED
#define SINUS_H_INCLUDED

#include "factorielle.hpp"
#include "puissance.hpp"

namespace isima { namespace metaprog {

// Cas r�cursif
template <short Degre>
struct Sinus
{
    // sin[n](x) = (-1)^n * x^(2n+1) / (2n+1)!
    static double evaluer(double x)
	{
	    double terme = Puissance<Degre>::evaluer(-1) * 
		               Puissance<2 * Degre + 1>::evaluer(x) / 
                       Factorielle<2 * Degre + 1>::valeur;
	    return terme + Sinus<Degre - 1>::evaluer(x);
	}
};

// Cas de base
template <>
struct Sinus<0>
{
    // sin[0](x) = 0
    static double evaluer(double x)
	{
	    return x;
	}
};


}} // namespace isima::metaprog

#endif // SINUS_H_INCLUDED