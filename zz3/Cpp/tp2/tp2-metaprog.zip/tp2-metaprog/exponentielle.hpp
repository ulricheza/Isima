#ifndef EXPONENTIELLE_H_INCLUDED
#define EXPONENTIELLE_H_INCLUDED

#include "factorielle.hpp"
#include "puissance.hpp"

namespace isima { namespace metaprog {

// Cas r�cursif
template <short Degre>
struct Exponentielle
{
    // exp[n](x) = ( x^k / k! ) + exp[n-1](x)
    static double evaluer(double x)
	{
	    double terme = Puissance<Degre>::evaluer(x) / Factorielle<Degre>::valeur;
	    return terme + Exponentielle<Degre - 1>::evaluer(x);
	}
};

// Cas de base
template <>
struct Exponentielle<0>
{
    // exp[0](x) = 0
    static double evaluer(double x)
	{
	    return 1.;
	}
};


}} // namespace isima::metaprog

#endif // EXPONENTIELLE_H_INCLUDED