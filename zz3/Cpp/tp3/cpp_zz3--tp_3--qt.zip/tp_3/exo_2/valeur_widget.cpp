// Entetes //---------------------------------------------------------------------------------------
#include <cmath>
#include <valeur_widget.hpp>

// Classe  V a l e u r W i d g e t //---------------------------------------------------------------

//-----------------------------------------------------------------------------------------SetValeur
void ValeurWidget::setValeur(double valeur) {
 if (_barre) {
  int pos = int(valeur/_pas);

  _spin->setValue(pos*_pas);
  _barre->setSliderPosition(pos);
 }
 else _valeur->setNum(valeur);
}

//--------------------------------------------------------------------------------------Constructeur
ValeurWidget::ValeurWidget(const char * intitule,QWidget * parent,double pas,double min,double max)
: QWidget(parent),
  _layout(new QHBoxLayout(this)),
  _intitule(new QLabel(intitule)),
  _valeur(pas==0.0 ? new QLabel : 0),
  _barre(pas!=0.0 ? new QSlider(Qt::Horizontal) : 0),_pas(pas),
  _spin(pas!=0.0 ? new QDoubleSpinBox : 0) {

 _layout->addWidget(_intitule);

 if (_barre) {
  _barre->setMinimum(int(std::floor(min/_pas)));
  _barre->setMaximum(int(std::ceil(max/_pas)));
  _barre->setMinimumWidth(100);

  _spin->setMinimum(0.0);
  _spin->setMaximum(20.0);
  _spin->setSingleStep(0.1);
  _spin->setDecimals(1);
  _spin->setMinimumWidth(50);

  _layout->addWidget(_spin);
  _layout->addWidget(_barre);

  QObject::connect(_barre,SIGNAL(valueChanged(int)),this,SLOT(barreChangee(int)));
 }
 else {
  _valeur->setFrameStyle(QFrame::StyledPanel);
  _valeur->setMinimumWidth(40);
  _layout->addWidget(_valeur);
 }

 _layout->addStretch();
}

//--------------------------------------------------------------------------------------BarreChangee
void ValeurWidget::barreChangee(int position) {
 _spin->setValue(position*_pas);
 emit(valeurChangee(position*_pas));
}

// Fin //-------------------------------------------------------------------------------------------
