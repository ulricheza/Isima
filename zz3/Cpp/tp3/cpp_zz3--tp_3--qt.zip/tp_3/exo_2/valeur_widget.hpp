// Gardien //---------------------------------------------------------------------------------------
#ifndef _VALEUR_WIDGET_HPP_
#define _VALEUR_WIDGET_HPP_

// Entetes //---------------------------------------------------------------------------------------
#include <QDoubleSpinBox>
#include <QHBoxLayout>
#include <QLabel>
#include <QSlider>

// Classe  V a l e u r W i d g e t //---------------------------------------------------------------
class ValeurWidget : public QWidget {
 Q_OBJECT
 //----------------------------------------------------------------------------------------Attributs
 protected: QHBoxLayout *    _layout;
 protected: QLabel *         _intitule;
 protected: QLabel *         _valeur;
 protected: QSlider *        _barre;
 protected: double           _pas;
 protected: QDoubleSpinBox * _spin;
 //---------------------------------------------------------------------------------------Accesseurs
 public: void setIntitule(const char * intitule) { _intitule->setText(intitule); }
 public: void setValeur(double);
 //------------------------------------------------------------------------------------Constructeurs
 public: ValeurWidget(const char *,QWidget * = 0,double = 0.0,double = 0.0,double = 0.0);
 //------------------------------------------------------------------------------------------Signaux
 signals:
  void valeurChangee(double);
 //--------------------------------------------------------------------------------------------Slots
 public slots:
  void barreChangee(int);
};

// Fin //-------------------------------------------------------------------------------------------
#endif
