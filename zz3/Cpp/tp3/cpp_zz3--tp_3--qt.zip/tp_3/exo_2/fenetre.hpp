// Gardien //---------------------------------------------------------------------------------------
#ifndef _FENETRE_HPP_
#define _FENETRE_HPP_

// Entetes //---------------------------------------------------------------------------------------
#include <QMainWindow>
#include <QTextEdit>
#include <valeur_widget.hpp>
#include <stats.hpp>

// Classe  F e n e t r e //-------------------------------------------------------------------------
class Fenetre : public QMainWindow {
 Q_OBJECT
 //----------------------------------------------------------------------------------------Attributs
 protected: Stats *        _stats;
 protected: QTextEdit *    _liste;
 protected: ValeurWidget * _nombre;
 protected: ValeurWidget * _moyenne;
 protected: ValeurWidget * _ecartType;
 //------------------------------------------------------------------------------------Constructeurs
 public: Fenetre(Stats *,QWidget * = 0);
 //--------------------------------------------------------------------------------------------Slots
 public slots:
  void annuler(void) { _stats->annuler(); }
  void charger(void);
  void quitter(void) { close(); }
  void rafraichir(void);
  void sauver(void);
};

// Fin //-------------------------------------------------------------------------------------------
#endif
