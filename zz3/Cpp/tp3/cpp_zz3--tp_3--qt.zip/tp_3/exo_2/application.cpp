// Entetes //---------------------------------------------------------------------------------------
#include <QApplication>
#include <fenetre.hpp>
#include <stats.hpp>

// Fonction principale //---------------------------------------------------------------------------
int main(int argc,char ** argv) {
 QApplication appli(argc,argv);
 Stats stats;
 Fenetre fenetre(&stats);

 fenetre.show();
 return appli.exec();
}

// Fin //-------------------------------------------------------------------------------------------
