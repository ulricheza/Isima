// Entetes //---------------------------------------------------------------------------------------
#include <sstream>
#include <QMenuBar>
#include <QFileDialog>
#include <QStatusBar>
#include <fenetre.hpp>

// Implementation  F e n e t r e //-----------------------------------------------------------------

//--------------------------------------------------------------------------------------Constructeur
Fenetre::Fenetre(Stats * stats,QWidget * parent)
: QMainWindow(parent),
  _stats(stats),
  _liste(new QTextEdit),
  _nombre(new ValeurWidget("Nombre :",this)),
  _moyenne(new ValeurWidget("Moyenne :",this,0.1,0.0,20.0)),
  _ecartType(new ValeurWidget("Ecart-type :",this)) {

 QMenuBar * barreMenu = new QMenuBar(this);
 QMenu * menuFichier = new QMenu("&Fichier",this);
 QMenu * menuEdition = new QMenu("&Edition",this);
 QAction * quitter = new QAction("&Quitter",this);
 QAction * charger = new QAction("&Charger",this);
 QAction * sauver = new QAction("&Sauver",this);
 QAction * annuler = new QAction("&Annuler",this);

 setMenuBar(barreMenu);
 barreMenu->addMenu(menuFichier);
 barreMenu->addMenu(menuEdition);
 menuFichier->addAction(charger);
 menuFichier->addAction(sauver);
 menuFichier->addSeparator();
 menuFichier->addAction(quitter);
 menuEdition->addAction(annuler);

 quitter->setShortcut(QString("Ctrl+W"));
 quitter->setStatusTip("Quitter l'application");

 charger->setShortcut(QString("Ctrl+O"));
 charger->setStatusTip("Charger un fichier");

 sauver->setShortcut(QString("Ctrl+S"));
 sauver->setStatusTip("Sauver un fichier");

 annuler->setShortcut(QString("Ctrl+Z"));
 annuler->setStatusTip("Annuler la derni�re op�ration");

 statusBar()->showMessage(""); // rend la barre d'etat visible

 QObject::connect(quitter,SIGNAL(triggered(void)),this,SLOT(quitter(void))); // ou close()
 QObject::connect(charger,SIGNAL(triggered(void)),this,SLOT(charger(void)));
 QObject::connect(sauver,SIGNAL(triggered(void)),this,SLOT(sauver(void)));
 QObject::connect(annuler,SIGNAL(triggered(void)),stats,SLOT(annuler(void)));

 QWidget * widgetCentral = new QWidget(this);
 QHBoxLayout * layoutPrincipal = new QHBoxLayout(widgetCentral);
 QVBoxLayout * layoutGauche = new QVBoxLayout();
 QVBoxLayout * layoutDroite = new QVBoxLayout();

 setCentralWidget(widgetCentral);
 layoutPrincipal->addLayout(layoutGauche);
 layoutPrincipal->addLayout(layoutDroite);

 _liste->setReadOnly(true);
 layoutGauche->addWidget(_liste);
 layoutDroite->addStretch();
 layoutDroite->addWidget(_nombre);
 layoutDroite->addWidget(_moyenne);
 layoutDroite->addWidget(_ecartType);
 layoutDroite->addStretch();

 QObject::connect(_stats,SIGNAL(donneesChangees(void)),this,SLOT(rafraichir(void)));
}

//-------------------------------------------------------------------------------------------Charger
void Fenetre::charger(void) {
 QString fichier = QFileDialog::getOpenFileName(this,"Ouvrir un fichier","",
                                                "Fichiers texte (*.txt);;Tous types (*.*)");

 if (fichier!="") _stats->chargerValeurs(fichier.toAscii());
}

//----------------------------------------------------------------------------------------Rafraichir
void Fenetre::rafraichir(void) {
 std::stringstream flux;

 QObject::disconnect(_moyenne,SIGNAL(valeurChangee(double)),_stats,SLOT(translater(double)));

 flux << *_stats;
 _liste->document()->setPlainText(flux.str().data());
 _nombre->setValeur(_stats->getNbValeur());
 _moyenne->setValeur(_stats->getMoyenne());
 _ecartType->setValeur(_stats->getEcartType());

 QObject::connect(_moyenne,SIGNAL(valeurChangee(double)),_stats,SLOT(translater(double)));
}

//--------------------------------------------------------------------------------------------Sauver
void Fenetre::sauver(void) {
 QString fichier = QFileDialog::getSaveFileName(this,"Enregistrer un fichier","",
                                                "Fichiers texte (*.txt);;Tous types (*.*)");

 if (fichier!="") _stats->sauverValeurs(fichier.toAscii());
}

// Fin //-------------------------------------------------------------------------------------------
