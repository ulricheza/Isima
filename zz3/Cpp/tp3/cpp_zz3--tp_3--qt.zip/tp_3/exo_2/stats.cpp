// Entetes //---------------------------------------------------------------------------------------
#include <cmath>
#include <fstream>
#include <stats.hpp>

// Implementation  S t a t s //---------------------------------------------------------------------

//----------------------------------------------------------------------------------------GetMoyenne
double Stats::getMoyenne(void) const {
 double somme = 0.0;
 int n = _valeurs.size();

 Stats::conteneur_t::const_iterator i;

 for (i=_valeurs.begin(); i!=_valeurs.end(); ++i) somme+=*i;
 return (n==0 ? 0 : somme/n);
}

//--------------------------------------------------------------------------------------GetEcartType
double Stats::getEcartType(void) const {
 double sommeCarre = 0.0;
 double somme = 0.0;
 int n = _valeurs.size();

 Stats::conteneur_t::const_iterator i;

 for (i=_valeurs.begin(); i!=_valeurs.end(); ++i) {
  somme+=*i;
  sommeCarre+=(*i)*(*i);
 }

 return (n==0 ? 0 : std::sqrt((sommeCarre/n - (somme/n)*(somme/n))));
}

//------------------------------------------------------------------------------------ChargerValeurs
void Stats::chargerValeurs(const char * fichier) {
 std::ifstream fin(fichier);

 int n;
 double v;

 fin >> n;
 _precedentes.push_back(_valeurs);
 _valeurs.clear();

 for (int i=0; i<n; ++i) {
  fin >> v;
  _valeurs.push_back(v);
 }

 fin.close();
 emit(donneesChangees());
}

//-------------------------------------------------------------------------------------SauverValeurs
void Stats::sauverValeurs(const char * fichier) {
 std::ofstream fout(fichier);

 Stats::conteneur_t::const_iterator i;

 fout << _valeurs.size() << std::endl;
 for (i=_valeurs.begin(); i!=_valeurs.end(); ++i) fout << *i << std::endl;
 fout.close();
}

//----------------------------------------------------------------------------------------Translater
void Stats::translater(double moyenne) {
 double diff = moyenne-getMoyenne();

 if (diff!=0.0) {
  Stats::conteneur_t::iterator i;

  _precedentes.push_back(_valeurs);
  for (i=_valeurs.begin(); i!=_valeurs.end(); ++i) (*i)+=diff;
  emit(donneesChangees());
 }
}

//-------------------------------------------------------------------------------------------Annuler
void Stats::annuler(void) {
 if (_precedentes.size()!=0) {
  _valeurs=_precedentes.back();
  _precedentes.pop_back();
  emit(donneesChangees());
 }
}

// Fonctions //-------------------------------------------------------------------------------------

//---------------------------------------------------------------------------------------Operator <<
std::ostream & operator << (std::ostream & flux,const Stats & stats) {
 Stats::conteneur_t::const_iterator i;

 for (i=stats._valeurs.begin(); i!=stats._valeurs.end(); ++i) flux << *i << std::endl;
 return flux;
}

// Fin //-------------------------------------------------------------------------------------------
