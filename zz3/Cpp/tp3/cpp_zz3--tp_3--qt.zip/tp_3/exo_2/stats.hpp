// Gardien //---------------------------------------------------------------------------------------
#ifndef _STATS_HPP_
#define _STATS_HPP_

// Entetes //---------------------------------------------------------------------------------------
#include <vector>
#include <QObject>

// Declarations Anticipees //-----------------------------------------------------------------------
class Stats;

// Declarations fonctions //------------------------------------------------------------------------
std::ostream & operator << (std::ostream &,const Stats &);

// Classe  S t a t s //-----------------------------------------------------------------------------
class Stats : public QObject {
 Q_OBJECT;
 //--------------------------------------------------------------------------------------------Amies
 friend std::ostream & operator << (std::ostream &,const Stats &);
 //--------------------------------------------------------------------------------------------Types
 protected: typedef std::vector<double> conteneur_t;
 //----------------------------------------------------------------------------------------Attributs
 protected: std::vector<double>                _valeurs;
 protected: std::vector< std::vector<double> > _precedentes;
 //---------------------------------------------------------------------------------------Accesseurs
 public: int getNbValeur(void) const { return _valeurs.size(); }
 //------------------------------------------------------------------------------------Constructeurs
 public: Stats(QObject * parent = 0) : QObject(parent) {}
 //-------------------------------------------------------------------------------Methodes publiques
 public: double getMoyenne(void) const;
 public: double getEcartType(void) const;

 public: void chargerValeurs(const char *);
 public: void sauverValeurs(const char *);
 //------------------------------------------------------------------------------------------Signaux
 signals:
  void donneesChangees(void);
 //--------------------------------------------------------------------------------------------Slots
 public slots:
  void translater(double);
  void annuler(void);
};

// Fin //-------------------------------------------------------------------------------------------
#endif
