// Entetes //---------------------------------------------------------------------------------------
#include <groupe1.hpp>

// Implementation  G r o u p e C o m p t e u r 1 //-------------------------------------------------

//-------------------------------------------------------------------------------------------Ajouter
void GroupeCompteur1::ajouter(Compteur & compteur) {
 for (conteneur_t::iterator i = _conteneur.begin(); i!=_conteneur.end(); ++i) {
  QObject::connect(&compteur,SIGNAL(valeurChangee(int)),*i,SLOT(setValeur(int)));
  QObject::connect(*i,SIGNAL(valeurChangee(int)),&compteur,SLOT(setValeur(int)));
 }

 _conteneur.push_back(&compteur);
}

//-----------------------------------------------------------------------------------------Supprimer
void GroupeCompteur1::supprimer(Compteur & compteur) {
 _conteneur.remove(&compteur);

 for (conteneur_t::iterator i = _conteneur.begin(); i!=_conteneur.end(); ++i) {
  QObject::disconnect(&compteur,SIGNAL(valeurChangee(int)),*i,SLOT(setValeur(int)));
  QObject::disconnect(*i,SIGNAL(valeurChangee(int)),&compteur,SLOT(setValeur(int)));
 }
}

// Fonctions //-------------------------------------------------------------------------------------

//---------------------------------------------------------------------------------------Operator <<
std::ostream & operator << (std::ostream & flux,const GroupeCompteur1 & groupe) {
 GroupeCompteur1::conteneur_t::const_iterator i;

 for (i=groupe._conteneur.begin(); i!=groupe._conteneur.end(); ++i)
  flux << (*i)->getValeur() << " ";

 return flux;
}

// Fin //-------------------------------------------------------------------------------------------
