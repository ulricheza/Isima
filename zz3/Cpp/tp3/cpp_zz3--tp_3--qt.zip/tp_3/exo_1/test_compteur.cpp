// Entetes //---------------------------------------------------------------------------------------
#include <groupe1.hpp>
#include <groupe2.hpp>

//--------------------------------------------------------------------------------------TesterGroupe
template <class G> void testerGroupe(void) {
 G groupe;

 Compteur c1(3);
 Compteur c2(5);
 Compteur c3(7);

 groupe.ajouter(c1);
 groupe.ajouter(c2);
 groupe.ajouter(c3);

 std::cout << "groupe = " << groupe << std::endl;

 c1.setValeur(13);
 std::cout << "groupe = " << groupe << std::endl;

 groupe.supprimer(c2);
 std::cout << "groupe = " << groupe << std::endl;

 c1.setValeur(7);
 std::cout << "groupe = " << groupe << std::endl;
 std::cout << "c2 = " << c2.getValeur() << std::endl;
}

//----------------------------------------------------------------------------------------------Main
int main(int,char **) {
 Compteur c1(3);
 Compteur c2(7);

 std::cout << "TEST COMPTEURS" << std::endl;
 std::cout << "c1 = " << c1.getValeur() << "; c2 = " << c2.getValeur() << std::endl;

 QObject::connect(&c1,SIGNAL(valeurChangee(int)),&c2,SLOT(setValeur(int)));
 QObject::connect(&c2,SIGNAL(valeurChangee(int)),&c1,SLOT(setValeur(int)));

 c1.setValeur(5);
 std::cout << "c1 = " << c1.getValeur() << "; c2 = " << c2.getValeur() << std::endl;

 c2.setValeur(9);
 std::cout << "c1 = " << c1.getValeur() << "; c2 = " << c2.getValeur() << std::endl;

 std::cout << std::endl << "TEST GROUPE 1" << std::endl;
 testerGroupe<GroupeCompteur1>();

 std::cout << std::endl << "TEST GROUPE 2" << std::endl;
 testerGroupe<GroupeCompteur2>();

 return 0;
}

// Fin //-------------------------------------------------------------------------------------------
