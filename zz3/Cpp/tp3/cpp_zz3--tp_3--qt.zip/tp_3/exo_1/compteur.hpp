// Gardien //---------------------------------------------------------------------------------------
#ifndef _COMPTEUR_HPP_
#define _COMPTEUR_HPP_

// Entetes //---------------------------------------------------------------------------------------
#include <iostream>
#include <QObject>

// Classe  C o m p t e u r //-----------------------------------------------------------------------
class Compteur : public QObject {
 Q_OBJECT
 //----------------------------------------------------------------------------------------Attributs
 protected: int _valeur;
 //---------------------------------------------------------------------------------------Accesseurs
 public: int getValeur(void) const { return _valeur; }
 //-------------------------------------------------------------------------------------Constructeur
 public: Compteur(int valeur = 0,QObject * parent = 0) : QObject(parent),_valeur(valeur) {}
 //------------------------------------------------------------------------------------------Signaux
 signals:
  void valeurChangee(int);
 //--------------------------------------------------------------------------------------------Slots
 public slots:
  void setValeur(int valeur) {
   if (valeur!=_valeur) {
    _valeur=valeur;
    emit(valeurChangee(valeur));
   }
  }
};

// Declaration fonctions //-------------------------------------------------------------------------
inline std::ostream & operator << (std::ostream & flux,const Compteur & compteur) {
 flux << compteur.getValeur();
 return flux;
}

// Fin //-------------------------------------------------------------------------------------------
#endif
