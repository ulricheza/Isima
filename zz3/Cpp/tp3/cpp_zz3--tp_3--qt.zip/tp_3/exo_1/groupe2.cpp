// Entetes //---------------------------------------------------------------------------------------
#include <groupe2.hpp>

// Implementation  G r o u p e C o m p t e u r 2 //-------------------------------------------------

//-------------------------------------------------------------------------------------------Ajouter
void GroupeCompteur2::ajouter(Compteur & compteur) {
 QObject::connect(&compteur,SIGNAL(valeurChangee(int)),this,SLOT(setValeur(int)));
 _conteneur.push_back(&compteur);
}

//-----------------------------------------------------------------------------------------Supprimer
void GroupeCompteur2::supprimer(Compteur & compteur) {
 _conteneur.remove(&compteur);
 QObject::disconnect(&compteur,SIGNAL(valeurChangee(int)),this,SLOT(setValeur(int)));
 // compteur.disconnect(this,SLOT(setValeur(int))); // Autre solution
}

//-----------------------------------------------------------------------------------------SetValeur
void GroupeCompteur2::setValeur(int valeur) {
 for (conteneur_t::iterator i = _conteneur.begin(); i!=_conteneur.end(); ++i)
  (*i)->setValeur(valeur);
}

// Fonctions //-------------------------------------------------------------------------------------

//---------------------------------------------------------------------------------------Operator <<
std::ostream & operator << (std::ostream & flux,const GroupeCompteur2 & groupe) {
 GroupeCompteur2::conteneur_t::const_iterator i;

 for (i=groupe._conteneur.begin(); i!=groupe._conteneur.end(); ++i)
  flux << (*i)->getValeur() << " ";

 return flux;
}

// Fin //-------------------------------------------------------------------------------------------
