// Gardien //---------------------------------------------------------------------------------------
#ifndef _GROUPE2_HPP_
#define _GROUPE2_HPP_

// Entetes //---------------------------------------------------------------------------------------
#include <compteur.hpp>
#include <list>

// Declarations anticipees //-----------------------------------------------------------------------
class GroupeCompteur2;

// Declarations fonctions //------------------------------------------------------------------------
std::ostream & operator << (std::ostream &,const GroupeCompteur2 &);

// Classe  G r o u p e C o m p t e u r 2 //---------------------------------------------------------
class GroupeCompteur2 : public QObject {
 Q_OBJECT
 //---------------------------------------------------------------------------------------------Amis
 friend std::ostream & operator << (std::ostream &,const GroupeCompteur2 &);
 //--------------------------------------------------------------------------------------------Types
 protected: typedef std::list<Compteur *> conteneur_t;
 //----------------------------------------------------------------------------------------Attributs
 protected: conteneur_t _conteneur;
 //-------------------------------------------------------------------------------Methodes publiques
 public: void ajouter(Compteur &);
 public: void supprimer(Compteur &);
 //--------------------------------------------------------------------------------------------Slots
 public slots:
  void setValeur(int);
};

// Fin //-------------------------------------------------------------------------------------------
#endif
