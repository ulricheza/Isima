// Gardien //---------------------------------------------------------------------------------------
#ifndef _GROUPE1_HPP_
#define _GROUPE1_HPP_

// Entetes //---------------------------------------------------------------------------------------
#include <compteur.hpp>
#include <list>

// Declarations anticipees //-----------------------------------------------------------------------
class GroupeCompteur1;

// Declarations fonctions //------------------------------------------------------------------------
std::ostream & operator << (std::ostream &,const GroupeCompteur1 &);

// Classe  G r o u p e C o m p t e u r 1 //---------------------------------------------------------
class GroupeCompteur1 {
 //---------------------------------------------------------------------------------------------Amis
 friend std::ostream & operator << (std::ostream &,const GroupeCompteur1 &);
 //--------------------------------------------------------------------------------------------Types
 protected: typedef std::list<Compteur *> conteneur_t;
 //----------------------------------------------------------------------------------------Attributs
 protected: conteneur_t _conteneur;
 //-------------------------------------------------------------------------------Methodes publiques
 public: void ajouter(Compteur &);
 public: void supprimer(Compteur &);
};

// Fin //-------------------------------------------------------------------------------------------
#endif
