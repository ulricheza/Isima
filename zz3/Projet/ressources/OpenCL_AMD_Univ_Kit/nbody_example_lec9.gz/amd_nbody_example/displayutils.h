#include <CL/cl.h>
#include <cmath>
#include <malloc.h>

#include <CL/cl.h>

void GLInit();


void idle();

void reShape(int w,int h);

void displayfunc();

void keyboardFunc(unsigned char key, int mouseX, int mouseY);

void printStats();
