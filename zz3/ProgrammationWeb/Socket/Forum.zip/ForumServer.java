import java.net.*;
import java.io.*;
import java.util.*;

class ForumServer {
	ServerSocket sock;
	int port = 7777;
	final static String Id = "Chatterbox";		// Chat server name
	ArrayList clients;							// Users on line (each user is represented by a ChatManager object)

	/*	***********	*/
	/*	CONSTRUCTOR	*/
	/*	***********	*/

	ForumServer() {
		clients = new ArrayList();
		try {
			sock = new ServerSocket(port);
			System.out.println("Server is running on " + port);
		} catch (IOException e) {
			System.err.println("Launching error !!!");
			System.exit(0);
		}
	}

	/*	***************	*/
	/*	CLIENT MANAGER	*/
	/*	***************	*/

	class ChatManager extends Thread {
		Socket sockC;							// Client socket
		BufferedReader reader;					// Reader on client socket
		PrintWriter writer;						// Writer on client socket
		String clientIP;						// Client machine

		ChatManager(Socket sk, String ip) {
			sockC = sk;
			clientIP = ip;
			try {
				reader = new BufferedReader(new InputStreamReader(sk.getInputStream()));
				writer = new PrintWriter(sk.getOutputStream(), true);
			} catch (IOException e) {
				System.err.println("IO error !!! on server");
			}
		}

		public void send(String mess) {			// Send the given message to the client
			writer.println(mess);
		}

		public void broadcast(String mess) {	// Send the given message to all the connected users
			synchronized(clients) {
				for (int i = 0; i < clients.size(); i++) {
					ChatManager gct = (ChatManager) clients.get(i);
					if (gct != null) gct.send(mess);
				}
			}
		}

		public void run() {						// Regular activity (as a thread): treat the command received from the client
			String st;
			try {
				while ((st = reader.readLine()) != null) {
					switch(st.charAt(0)) {
						case '?' : send("> Welcome " + st.substring(2));break;
						case '!' : broadcast("All> " + st.substring(2));break;
						default : send("> I don't understand '" + st + "'");
					}
				}
			} catch (IOException e) {
				System.err.println(e.getMessage());
			}
		}

		public void close() {
			if (sockC == null) return;
			try {
				sockC.close();
				sockC = null;
			} catch (IOException e) {
				System.err.println("Connection closing error with " + clientIP);
			}
		}
	}

	/*	***********	*/
	/*	LAUNCHING	*/
	/*	***********	*/

	public static void main(String[] arg) {
		ForumServer me = new ForumServer();
		me.process();
	}

	public void process() {
		try {
			while (true) {
				Socket userSock = sock.accept();
				String userName = userSock.getInetAddress().getHostName();
				ChatManager user = new ChatManager(userSock, userName);
				synchronized(clients) {
					clients.add(user);
					user.start();
					user.send(userName + ": client " + clients.size() + " on line");
				}
			}
		} catch(IOException e) {
			System.err.println("Server error !!!");
			System.exit(0);
		}
	}
}