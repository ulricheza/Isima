
import java.io.*;
import java.util.*;
import javax.servlet.*;

public class Hello implements Servlet {

    int count;
    private ServletConfig config;

    public void init(ServletConfig config) throws ServletException {
        this.config = config;
        count = 0;
    }

    public ServletConfig getServletConfig() {
        return this.config;
    }

    public String getServletInfo() {
        String t = "info sur la servlet";
        return t;
    }

    public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException {
        count++; 
    }

    public void destroy() {}
}
