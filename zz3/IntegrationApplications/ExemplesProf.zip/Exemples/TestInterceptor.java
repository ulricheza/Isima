package com.jmd.test.domaine.ejb;

import com.jmd.test.domaine.entity.Personne;
import java.util.List;
import javax.ejb.Stateless;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

@Stateless
@Interceptors({ com.jmd.test.domaine.ejb.MonIntercepteur.class}) 
public class PersonneFacade implements PersonneFacadeLocal, PersonneFacadeRemote {
    @PersistenceContext
    private EntityManager em;

    public void create(Personne personne) {
        em.persist(personne);
    }

... 

    public List<Personne> findAll() {
        return em.createQuery("select object(o) from Personne as o").getResultList();
    }

}