package com.jmd.test.domaine.ejb;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.interceptor.AroundInvoke;
import javax.interceptor.InvocationContext;

public class MonIntercepteur {

    @AroundInvoke
    public Object audit(InvocationContext ic)
            throws Exception {
        System.out.println("MonIntercepteur Invocation de la methode : " + ic.getMethod());
        return ic.proceed();
    }

    @PreDestroy
    public void preDestroy(InvocationContext ic) {
        System.out.println("MonIntercepteur suppression du bean : " + ic.getTarget());
    }

    @PostConstruct
    public void postConstruct(InvocationContext ic) {
        System.out.println("MonIntercepteur Creation du bean : " + ic.getTarget());
    }
}