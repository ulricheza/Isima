public void _jspService(HttpServletRequest request,
                        HttpServletResponse response)
throws java.io.IOException, ServletException {
    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;

    try {
        response.setContentType("text/html");
        response.setHeader("X-Powered-By", "JSP/2.1");
        pageContext = _jspxFactory.getPageContext(this, request, response, null, true, 8192, true);
        _jspx_page_context = pageContext;
        application = pageContext.getServletContext();
        config = pageContext.getServletConfig();
        session = pageContext.getSession();
        out = pageContext.getOut();
        _jspx_out = out;
        _jspx_resourceInjector = (org.glassfish.jsp.api.ResourceInjector) application.getAttribute("com.sun.appserv.jsp.resource.injector");

        out.write("<html>\r\n");
        out.write("<body>\r\n");
        out.println("Hello World");
        out.write("\r\n");
        out.write("</body>\r\n");
        out.write("</html>\r\n");
        out.write("\r\n");
    } catch ...