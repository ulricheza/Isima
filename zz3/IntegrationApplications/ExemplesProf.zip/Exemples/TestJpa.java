
import entity.Clients;
import javax.persistence.*;

public class TestJpa {

    public static void main(String[] argv) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("WebApplication1PU");
        EntityManager em = emf.createEntityManager();

        Clients clt = em.find(Clients.class, 1L);
        if (clt != null) {
            System.out.println("Clients.nom: " + clt.getNom());
        }

        em.close();
        emf.close();
    }
}