
import java.sql.*;
import javax.sql.*;
import javax.naming.*;

public class TestJpc {

    public static void main(java.lang.String[] args) {
        try {
            Context ctx = new InitialContext();
            DataSource ds = (DataSource) ctx.lookup("jdbc/base_medecin_2011");
            Connection con = ds.getConnection("root", "root");
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        
        con.close();
        ds.close();
    }
}
